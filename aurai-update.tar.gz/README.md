# Aurai Companion

Aurai Companion is a mobile-first companion for **Outward**. It is built for the things that are awkward to look up while you are playing: crafting recipes, alchemy, cooking, blacksmith commissions, ingredient matching, shopping lists and quick links to the Outward Wiki.

The Android build keeps its built-in crafting catalogue on the phone, so the main search and inventory tools work offline. When the wiki recipe index is available, Aurai can also cache a larger recipe database.

## What it does

- Search by craft name, ingredient, purpose or crafting method.
- Handles common typos and UK/US spelling such as **armour / armor**.
- Covers Survival, Cooking, Alchemy and blacksmith commissions.
- **My Items** shows what you can make now and what you are closest to making.
- Add several inventory items at once, including quantities such as `5x Blue Sand`.
- Track silver for blacksmith commissions.
- Tap an ingredient to see crafts that use it.
- Save recipes, inventory loadouts and shopping plans.
- Compare crafts with a searchable picker.
- Back up and restore local app data.
- Open detailed item, quest, enemy and location pages through Wiki Explorer.

## Blue Sand armour

Blue Sand equipment is not a normal manual recipe. It is commissioned from **Loud-Hammer in Cierzo**, so Aurai lists it under **Blacksmith**:

- Blue Sand Armor — 5 Blue Sand + 400 silver
- Blue Sand Boots — 2 Blue Sand + 200 silver
- Blue Sand Helm — 3 Blue Sand + 250 silver

A full-set planning entry is also included.

## Offline data

The built-in catalogue is always available offline. A larger standard recipe index can be synced from the Outward Wiki and cached on the device when that endpoint is available. Wiki Explorer itself needs internet access.

## Android builds

The repository uses the signed GitHub Actions build workflow. As long as the same signing key is retained, future APK releases install over the existing signed app without wiping local data.

## Project structure

```text
index.html
styles.css
app.js
data.js
sw.js
manifest.webmanifest
icon.svg
icon-192.png
icon-512.png
android/
```

No JavaScript framework or backend is required.

## Attribution

Aurai Companion is a fan-made project and is not affiliated with Nine Dots Studio.

Game information and links are based on the community-maintained Outward Wiki. Wiki-derived material should be used in accordance with the wiki's licence and attribution requirements.
