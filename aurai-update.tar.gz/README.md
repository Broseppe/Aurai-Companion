# Aurai Companion

Aurai Companion is a small mobile companion for **Outward**. It is meant to be quick to use while you are actually playing: search a recipe, check what you can make from the ingredients in your bag, save useful recipes, or jump into the Outward Wiki when you need more detail.

## What it does

- Search the built-in quick-reference recipes by name, effect or ingredients.
- Filter recipes into Survival, Cooking and Alchemy.
- Add ingredients to **My Items** and see:
  - recipes you can make right now;
  - the closest matches;
  - exactly which ingredients are still missing.
- Save favourite recipes on the device.
- Open short field guides for common gameplay questions.
- Search the current Outward Wiki without bundling a large offline copy of it.
- Run as an installable web app or as an Android APK.

## Version 2.2

This update is mostly about making the app easier to use on a phone.

- Fixed the Alchemy and Cooking quick-access buttons on the home screen.
- Fixed the update banner appearing when there was no usable update.
- Added a **Later** button so web updates never block the bottom of the screen.
- Android builds no longer show the web/PWA update prompt.
- Improved recipe search so several words can be used together, such as `water beetle`.
- Reworked **My Items** so it shows both complete recipes and near matches.
- Added missing-ingredient information and `Have X/Y` progress on near matches.
- Added + / − quantity controls for ingredients.
- Added quick-add ingredient shortcuts when the inventory is empty.
- Added a filter for the recipes matched from My Items.
- Recipe details now compare the recipe with My Items when possible.

## Using My Items

Open **My Items** and add the ingredients you currently have. You do not need to type the same ingredient repeatedly: use the + and − buttons to adjust the amount.

The results are split into two sections:

**Craftable now** shows recipes for which you already have everything required.

**Closest matches** shows recipes that use at least one of your ingredients, sorted by how little you are missing. Each card tells you what is still needed.

This is useful when you have a handful of ingredients and want to know what they are closest to making rather than searching every recipe manually.

## Wiki search

The full wiki is not copied into the app. Wiki Explorer searches the current Outward Wiki online and opens the original page when you choose a result. The compact recipe list and saved data remain available in the app itself.

## Android builds

The Android version is built in GitHub Actions. Run **Aurai Companion Update & Build**, then download the `Aurai-Companion-Android` artifact from the finished run and install the APK on your phone.

For normal updates, upload the supplied `aurai-update.tar.gz` to the repository root and run the same workflow. The workflow applies the update, rebuilds the APK and provides a new artifact.

## Project layout

```text
Aurai Companion/
├── index.html
├── styles.css
├── app.js
├── data.js
├── sw.js
├── manifest.webmanifest
├── icon.svg
├── icon-192.png
├── icon-512.png
└── android/
```

## Notes

Aurai Companion is an unofficial fan-made project and is not affiliated with Nine Dots Studio. Wiki links point to `outward.wiki.gg`; content on the wiki remains subject to the wiki's own licence and terms.
