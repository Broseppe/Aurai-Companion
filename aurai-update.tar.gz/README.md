# Aurai Companion

Aurai Companion is a phone-first reference app for **Outward**. It is designed for the moments when you know roughly what you want to make, or what is in your bag, but do not want to dig through several wiki pages to work it out.

The app keeps its core recipe and blacksmith library on the phone, so recipe search and **My Items** still work without an internet connection. Detailed articles, quests, enemies and locations open on the Outward Wiki when you want the full reference.

## Main features

- Search recipes by name, ingredient, effect, blacksmith or location.
- Search naturally: `blue sand armour crafting`, `cierzo smith`, `water beetle` and similar wording all work.
- UK/US wording such as **armour / armor** is normalised automatically.
- Small spelling mistakes are tolerated, for example `livweedy` can still lead to Livweedi recipes.
- Add several ingredients to **My Items** at once, including quantities such as `3x Blue Sand`.
- See recipes grouped into:
  - **Ready now**;
  - **Missing one item**;
  - **Missing two items**;
  - further related recipes.
- Tap an ingredient to see recipes and commissions that use it.
- Save My Items loadouts for later.
- Build a combined **Shopping List** across several planned recipes, including silver needed for blacksmith commissions.
- Compare two recipes side by side.
- Save favourite recipes locally.
- Back up and restore your app data from **Settings & Data**.
- Use **Wiki Explorer** for local matches first, then jump to the full Outward Wiki without relying on its API.

## Offline recipe library

The recipe library ships inside Aurai Companion. There is no background recipe sync and no dependency on the wiki's internal API, so a wiki-side API error cannot break the app's search screen.

The current library includes the original quick-reference recipes, more common cooking and alchemy recipes, and blacksmith commissions including Blue Sand, Antique Plate, Chalcedony, Copal, Hailfrost, Palladium, Petrified Wood, Tenebrous and Tsar equipment.

The library is deliberately structured data rather than copied wiki articles. Full descriptions and edge cases remain on `outward.wiki.gg`.

## My Items

You can enter one item:

```text
Livweedi
```

or several at once:

```text
Water, Ochre Spice Beetle, Livweedi
```

Quantities work in either direction:

```text
3x Blue Sand
Blue Sand x3
```

Aurai compares those quantities with each recipe and ranks the closest matches. This is useful when you have a handful of ingredients and want to know what is worth making before selling or dropping anything.

## Settings & Data

Open the side menu and choose **Settings & Data** to see the installed app version and local-data counts.

From there you can:

- copy a JSON backup;
- download a backup file where the device supports it;
- restore a backup by pasting the JSON;
- clear the obsolete recipe-sync cache left by older test releases;
- reset local app data if needed;
- open the GitHub project.

Backups contain favourites, My Items, shopping-list recipes, loadouts, comparison choices and recent wiki searches. They do not contain the built-in recipe library because that is already part of the app.

## Android updates

The Android APK is built and permanently signed through GitHub Actions.

For an app update:

1. Upload the supplied `aurai-update.tar.gz` to the repository root.
2. Run **Aurai Companion Signed Update & Build (Final Fix)** in GitHub Actions.
3. Download the `Aurai-Companion-Android-Signed` artifact.
4. Extract it and install `Aurai-Companion-Android.apk` over the existing signed installation.

The release signing key is stored through GitHub repository secrets and is not committed to the repository. Keep the separate signing-key backup safe; losing the release key would prevent future APKs from updating the installed app.

## Project structure

```text
Aurai Companion/
├── index.html
├── styles.css
├── app.js
├── data.js
├── sw.js
├── manifest.webmanifest
├── icon.svg
├── icon-192.png
├── icon-512.png
└── android/
```

The web app uses plain HTML, CSS and JavaScript. The Android project is a small WebView wrapper around the same interface, so most feature work only needs to be implemented once.

## Attribution

Aurai Companion is an unofficial fan-made project and is not affiliated with Nine Dots Studio.

Recipe facts and wiki links are based on the community-maintained **Outward Wiki** at `outward.wiki.gg`. Wiki content is generally available under **CC BY-NC-SA 4.0** unless a page states otherwise. Aurai keeps a compact structured reference library and links back to the original wiki pages rather than reproducing full articles.
