# Changelog

## 2.4.0

- Removed the broken live Cargo recipe sync that could expose raw `MWException` errors on Android.
- The recipe library now ships with the app and works offline without a manual sync.
- Added 44 blacksmith commission recipes to offline search.
- Added Blue Sand Armor, Boots and Helm with Loud-Hammer material and silver requirements.
- Added commission recipes for Antique Plate, Chalcedony, Copal, Hailfrost, Palladium, Petrified Wood, Tenebrous and Tsar equipment.
- Added a Blacksmith recipe filter.
- Blacksmith results show silver commission costs separately from materials.
- My Items treats blacksmith entries as material checks rather than normal hand-crafted recipes.
- Shopping lists now total silver required for planned blacksmith commissions.
- Empty recipe searches now offer a direct Wiki search instead of a dead end.
- Reworded database/status messages so the app no longer suggests a sync is required.
- Updated app, service-worker and Android version identifiers to 2.4.0.

## 2.3.1

- Prepared Android builds for permanent release signing.
- Increased Android version code so the first signed release has a clean upgrade path.
- Updated app, service-worker and Android version identifiers to 2.3.1.
- No recipe or interface features were removed.

## 2.3.0

- Added an offline recipe database using IndexedDB.
- Added background and manual recipe-index syncing from the Outward Wiki.
- Recipe matching now uses the synced database when available instead of only the starter set.
- Added fuzzy recipe and ingredient searching for small spelling mistakes.
- Added ingredient reverse lookup: tap an ingredient to see recipes that use it.
- Added purpose filters for healing, mana, stamina, weather, combat, travel and food.
- Added saved My Items loadouts.
- Added a Shopping List that combines missing ingredients across planned recipes.
- Added recipe comparison.
- Added several high-use alchemy recipes to the built-in starter set.
- Improved offline/online status messaging.
- Updated Android version to 2.3.0.

## 2.2.0

- Fixed the Alchemy and Cooking quick-access buttons.
- Fixed the update banner appearing when no usable update was waiting.
- Added a Later button to the web update prompt.
- Android builds no longer show the PWA update prompt.
- Improved multi-word recipe search.
- Reworked My Items with craftable and closest-match sections.
- Added ingredient quantities and missing-ingredient information.
