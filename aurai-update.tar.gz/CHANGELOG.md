# Changelog

## 2.2.0 — Search, My Items and mobile fixes

- Fixed the home-screen Alchemy and Cooking quick-access buttons.
- Fixed the update banner being visible when it should have been hidden.
- Added a dismiss option for web update notices.
- Disabled PWA update prompts in the Android wrapper.
- Added multi-term recipe searching.
- Added craftable and near-match recipe ranking from My Items.
- Added missing-ingredient and progress information.
- Added ingredient quantity controls and quick-add shortcuts.
- Added filtering within matched My Items recipes.
- Added My Items status to recipe details.
- Rewrote the README to be shorter and more natural.

## 2.1.0 — Mobile install and native-feel update

- Added custom Aurai compass icon and startup splash.
- Added improved bottom navigation and drawer navigation.
- Added live Wiki Explorer with category shortcuts and search fallback.
- Added network status messaging.
- Added PWA install guidance and install prompt handling.
- Added service-worker update detection and update banner.
- Improved recipe filtering and pantry duplicate-count handling.
- Added recipe sharing where supported.
- Added Android WebView wrapper project and cloud APK build.
