# Changelog

## 2.4.0

- Reworked crafting search around relevance instead of loose substring matching.
- Fixed searches such as `ammo` matching Ammolite and `sand` matching Sandwich.
- Added UK/US armour spelling handling and stronger typo tolerance.
- Added offline blacksmith commission entries, including Blue Sand armour and several major armour sets.
- Added silver tracking for commission readiness and shopping totals.
- Moved database controls out of the main recipe flow into Settings & Data.
- Replaced the large native Compare dropdown with a searchable picker.
- Added bulk ingredient entry such as `5x Blue Sand, Linen Cloth x2`.
- Added near-match controls in My Items.
- Added Settings & Data with backup, restore and local-data reset.
- Added Android file picker support for importing JSON backups.
- Added clearer no-result actions and direct Wiki fallback from crafting search.
- Improved mobile search layout so results appear sooner while the keyboard is open.
- Bumped Android version to 2.4.0 (versionCode 6).

## 2.3.1

- Prepared the app for permanent Android signing.

## 2.3.0

- Added cached recipe-index support, fuzzy ingredient matching, saved loadouts, shopping lists and recipe comparison.
