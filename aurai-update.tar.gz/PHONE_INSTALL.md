# Installing and updating on Android

Aurai Companion is built by GitHub Actions and installed from the generated APK.

## Update the app

1. Upload `aurai-update.tar.gz` to the root of the repository.
2. Open **Actions**.
3. Run **Aurai Companion Signed Update & Build (Final Fix)**.
4. When the run finishes, download the `Aurai-Companion-Android-Signed` artifact.
5. Extract it and open `Aurai-Companion-Android.apk`.
6. Install it over the existing signed Aurai Companion app.

Normal signed updates keep favourites, inventory and loadouts.

## Important

Keep the Android signing-key backup private and safe. Do not commit the key or signing secrets to the repository.
