# Installing and updating Aurai Companion from a phone

A PC is not required. GitHub Actions builds and signs the Android APK in the cloud.

## Build or update the app

1. Open the Aurai Companion repository on GitHub.
2. For a new app update, upload `aurai-update.tar.gz` to the **root of the repository**.
3. Open **Actions**.
4. Run **Aurai Companion Signed Update & Build (Final Fix)**.
5. Wait for the run to finish with a green tick.
6. Open the run and download the **Aurai-Companion-Android-Signed** artifact.
7. Extract the downloaded ZIP.
8. Open `Aurai-Companion-Android.apk` and install it.

Once a permanently signed Aurai Companion release is installed, later signed releases can normally be installed directly over it without uninstalling the app. This preserves favourites, My Items, loadouts and other local data.

## Signing key

The permanent Android signing key must remain private. Keep its backup somewhere safe outside the public GitHub repository.

If that key is lost, a newly generated key cannot be used to update an existing Aurai Companion installation signed with the old key.
