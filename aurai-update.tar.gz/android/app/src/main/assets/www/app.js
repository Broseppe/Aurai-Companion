const D = window.AURAI_DATA;
const APP_VERSION = '2.5.0';
const WIKI = 'https://outward.wiki.gg';
const IS_NATIVE = /AuraiAndroid/i.test(navigator.userAgent);
const IS_STANDALONE = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true || IS_NATIVE;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];


function readJSON(key, fallback){try{return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));}catch{return fallback;}}
function canon(v=''){return String(v).normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[’‘]/g,"'").replace(/[^a-z0-9' -]+/g,' ').replace(/\s+/g,' ').trim();}
function esc(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function stripHTML(v=''){const t=document.createElement('textarea');t.innerHTML=String(v).replace(/<[^>]*>/g,' ');return t.value.replace(/\s+/g,' ').trim();}
function haptic(){if(navigator.vibrate) navigator.vibrate(8);}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show');clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>t.classList.remove('show'),1900);}
async function copyText(value){
  const text=String(value||'');
  try{
    if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return true;}
  }catch{}
  try{
    const area=document.createElement('textarea');area.value=text;area.setAttribute('readonly','');area.style.position='fixed';area.style.opacity='0';document.body.appendChild(area);area.select();const ok=document.execCommand('copy');area.remove();return !!ok;
  }catch{return false;}
}
function dataBackupPayload(){
  return {
    app:'Aurai Companion',
    schema:1,
    appVersion:APP_VERSION,
    exportedAt:new Date().toISOString(),
    saved:[...state.saved],
    pantry:[...state.pantry],
    plan:[...state.plan],
    loadouts:state.loadouts,
    recentWiki:state.recentWiki,
    compareA:state.compareA||'',
    compareB:state.compareB||''
  };
}
function backupText(){return JSON.stringify(dataBackupPayload(),null,2);}
function applyBackupPayload(payload){
  if(!payload||typeof payload!=='object')throw new Error('Backup is not valid JSON data.');
  if(payload.app && payload.app!=='Aurai Companion')throw new Error('This backup is not from Aurai Companion.');
  const saved=Array.isArray(payload.saved)?payload.saved.filter(id=>getRecipe(id)):[];
  const pantry=Array.isArray(payload.pantry)?payload.pantry.filter(x=>typeof x==='string'&&x.trim()).map(normalizeIngredient):[];
  const plan=Array.isArray(payload.plan)?payload.plan.filter(id=>getRecipe(id)):[];
  const loadouts=Array.isArray(payload.loadouts)?payload.loadouts.filter(x=>x&&typeof x.name==='string'&&Array.isArray(x.items)).slice(0,30).map(x=>({...x,items:x.items.filter(i=>typeof i==='string').map(normalizeIngredient)})):[];
  const recentWiki=Array.isArray(payload.recentWiki)?payload.recentWiki.filter(x=>typeof x==='string').slice(0,6):[];
  state.saved=new Set(saved);state.pantry=pantry;state.plan=new Set(plan);state.loadouts=loadouts;state.recentWiki=recentWiki;
  state.compareA=getRecipe(payload.compareA)?payload.compareA:'';state.compareB=getRecipe(payload.compareB)?payload.compareB:'';
  saveState();
}
function downloadTextFile(filename,text,type='application/json'){
  try{
    const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);return true;
  }catch{return false;}
}
function wikiURL(page){return `${WIKI}/wiki/${encodeURIComponent(page).replace(/%20/g,'_')}`;}
function openExternal(url){if(IS_NATIVE){location.href=url;}else{window.open(url,'_blank','noopener,noreferrer');}}
function iconFor(type){return type==='Alchemy'?'⚗️':type==='Cooking'?'🍲':type==='Blacksmith'?'⚒️':type==='Crafting'?'🔨':'🛠️';}
function routeTitle(r){return ({home:'Home',recipes:'Recipes',pantry:'My Items',shopping:'Shopping List',compare:'Compare Recipes',wiki:'Wiki Explorer',guides:'Field Guides',saved:'Saved',settings:'Settings & Data'})[r] || 'Home';}
function countIngredients(items){const map=new Map();for(const item of items)map.set(item,(map.get(item)||0)+1);return [...map.entries()];}
function ingredientCountMap(items){const map={};for(const item of items){const k=canon(item);map[k]=(map[k]||0)+1;}return map;}

let catalogRecipes = D.recipes.map(r=>({...r,source:'bundled'}));
let ingredientNames = [];
let ingredientByKey = new Map();

const allowedRoutes = new Set(['home','recipes','pantry','shopping','compare','wiki','guides','saved','settings']);
const params = new URLSearchParams(location.search);
const initialRoute = allowedRoutes.has(params.get('route')) ? params.get('route') : 'home';
const state = {
  route: initialRoute,
  filter: 'All',
  purpose: 'All',
  query: '',
  pantryQuery: '',
  pantryType: 'All',
  ingredientQuery: '',
  wikiQuery: '',
  saved: new Set(readJSON('auraiSaved', [])),
  pantry: readJSON('auraiPantry', []),
  plan: new Set(readJSON('auraiPlan', [])),
  loadouts: readJSON('auraiLoadouts', []),
  recentWiki: readJSON('auraiRecentWiki', []),
  compareA: readJSON('auraiCompareA', ''),
  compareB: readJSON('auraiCompareB', '')
};

let deferredInstallPrompt = null;
let swRegistration = null;
let reloadingForUpdate = false;
const app = $('#app');

const PURPOSES = {
  All: [],
  Healing: ['heal','health','bandage','life potion'],
  Mana: ['mana','astral'],
  Stamina: ['stamina','endurance','able tea'],
  Weather: ['warm','cool','cold','hot','weather'],
  Combat: ['damage','imbue','varnish','rage','discipline','ammo','bomb','charge','rag'],
  Travel: ['travel','ration'],
  Food: ['food','drink','tea','stew','jerky','sandwich','cake','tartine'],
  Equipment: ['equipment','armor','boots','helm','weapon','blacksmith']
};

// Known ingredient-family substitutions that are explicitly useful in Outward.
// This is deliberately conservative: exact ingredients are always preferred.
const FULFILLS = {
  'raw meat': ['meat','ration ingredient'],
  'raw alpha meat': ['meat','ration ingredient'],
  'clean water': ['water'],
  'rancid water': ['water'],
  'leyline water': ['water'],
  'common mushroom': ['mushroom'],
  'woolshroom': ['mushroom'],
  'nightmare mushroom': ['mushroom'],
  'bread': ['bread (any)','ration ingredient']
};
const GENERIC_INGREDIENTS = new Set(['meat','ration ingredient','water','bread','egg','fish','mushroom','vegetable','basic armor','basic boots','basic helm']);

function saveState(){
  localStorage.setItem('auraiSaved',JSON.stringify([...state.saved]));
  localStorage.setItem('auraiPantry',JSON.stringify(state.pantry));
  localStorage.setItem('auraiPlan',JSON.stringify([...state.plan]));
  localStorage.setItem('auraiLoadouts',JSON.stringify(state.loadouts));
  localStorage.setItem('auraiRecentWiki',JSON.stringify(state.recentWiki.slice(0,6)));
  localStorage.setItem('auraiCompareA',JSON.stringify(state.compareA||''));
  localStorage.setItem('auraiCompareB',JSON.stringify(state.compareB||''));
}

function rebuildIngredientIndex(){
  ingredientNames=[...new Set(catalogRecipes.flatMap(r=>r.ingredients).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  ingredientByKey=new Map(ingredientNames.map(i=>[canon(i),i]));
}
rebuildIngredientIndex();


function getRecipe(id){return catalogRecipes.find(r=>r.id===id) || D.recipes.find(r=>r.id===id);}

function deleteLegacyRecipeCache(){
  try{
    if('indexedDB' in window) indexedDB.deleteDatabase('aurai-companion');
  }catch{}
}


function levenshtein(a,b){
  a=canon(a);b=canon(b);if(a===b)return 0;if(!a.length)return b.length;if(!b.length)return a.length;
  const prev=Array.from({length:b.length+1},(_,i)=>i);const cur=new Array(b.length+1);
  for(let i=1;i<=a.length;i++){
    cur[0]=i;
    for(let j=1;j<=b.length;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));
    for(let j=0;j<=b.length;j++)prev[j]=cur[j];
  }
  return prev[b.length];
}
function fuzzyTermMatch(term,haystack){
  term=canon(term);haystack=canon(haystack);if(!term)return true;if(haystack.includes(term))return true;
  const words=haystack.split(/\s+/).filter(Boolean);const max=term.length<=4?1:term.length<=8?2:3;
  return words.some(w=>Math.abs(w.length-term.length)<=max&&levenshtein(term,w)<=max);
}

const QUERY_ALIASES = {
  armour:'armor',armours:'armor',armored:'armor',
  helmet:'helm',helmets:'helm',
  smith:'blacksmith',smithing:'blacksmith',
  potions:'potion',foods:'food',weapons:'weapon',
  favourite:'favorite',favourites:'favorite'
};
const QUERY_STOP_WORDS = new Set(['craft','crafting','crafted','recipe','recipes','make','making','how','to','a','an','the','for','of','with','using','need','needs']);
function queryTerms(raw){
  return canon(raw).split(/[\s,;+\/]+/).filter(Boolean).map(t=>QUERY_ALIASES[t]||t).filter(t=>!QUERY_STOP_WORDS.has(t));
}
function normalizeQueryPhrase(raw){return queryTerms(raw).join(' ');}
function recipeHaystack(r){
  return [r.name,r.type,r.station,r.crafter||'',r.location||'',...(r.ingredients||[]),...(r.tags||[]),r.note||'',r.costSilver?`${r.costSilver} silver`:''].join(' ');
}
function recipeSearchScore(r,raw){
  const terms=queryTerms(raw);if(!terms.length)return 0;
  const hay=canon(recipeHaystack(r));
  if(!terms.every(t=>fuzzyTermMatch(t,hay)))return Infinity;

  const name=canon(r.name).replace(/\barmour\b/g,'armor').replace(/\bhelmet\b/g,'helm');
  const phrase=normalizeQueryPhrase(raw);
  let score=60;

  if(name===phrase)score=0;
  else if(phrase && name.includes(phrase))score=4;
  else if(terms.every(t=>name.includes(t)))score=8;
  else{
    let nameHits=0,ingredientHits=0,metaHits=0,fuzzyHits=0;
    const ingredients=canon((r.ingredients||[]).join(' '));
    const meta=canon([r.type,r.station,r.crafter||'',r.location||'',...(r.tags||[])].join(' '));
    for(const term of terms){
      if(name.includes(term))nameHits++;
      else if(ingredients.includes(term))ingredientHits++;
      else if(meta.includes(term))metaHits++;
      else if(fuzzyTermMatch(term,name))fuzzyHits++;
    }
    score=14 + ingredientHits*5 + metaHits*7 + fuzzyHits*9 - nameHits*3;
  }

  if(r.type==='Blacksmith' && terms.some(t=>t==='blacksmith'))score-=3;
  if(terms.some(t=>t==='armor') && /\barmor\b/.test(name))score-=2;
  return score;
}
function matchesTerms(r,raw){return recipeSearchScore(r,raw)!==Infinity;}
function matchesPurpose(r,purpose){if(!purpose||purpose==='All')return true;const keys=PURPOSES[purpose]||[];const hay=canon(recipeHaystack(r));return keys.some(k=>hay.includes(canon(k)));}
function ingredientSearchMatches(raw,limit=8){
  const q=canon(raw);if(!q)return [];
  const scored=ingredientNames.map(name=>{
    const c=canon(name);let score=99;
    if(c===q)score=0;else if(c.startsWith(q))score=1;else if(c.includes(q))score=2;else{const d=levenshtein(q,c);const word=Math.min(...c.split(' ').map(w=>levenshtein(q,w)));score=3+Math.min(d,word);}
    return {name,score};
  }).filter(x=>x.score<=Math.max(5,Math.floor(q.length/2)+2)).sort((a,b)=>a.score-b.score||a.name.localeCompare(b.name));
  return scored.slice(0,limit);
}
function normalizeIngredient(value){
  const v=String(value||'').trim();if(!v)return '';
  const exact=ingredientByKey.get(canon(v));if(exact)return exact;
  const best=ingredientSearchMatches(v,1)[0];
  if(best && best.score<=5)return best.name;
  return v;
}
function fulfillsItem(owned,needed){
  const o=canon(owned),n=canon(needed);if(o===n)return true;
  return (FULFILLS[o]||[]).includes(n);
}
function pantryStatus(r,items=state.pantry){
  const available=items.map((name,i)=>({name,key:canon(name),i,used:false}));
  const needs=(r.ingredients||[]).map(name=>({name,key:canon(name),generic:GENERIC_INGREDIENTS.has(canon(name))})).sort((a,b)=>Number(a.generic)-Number(b.generic));
  let haveUnits=0;const missingNames=[];
  for(const need of needs){
    let idx=available.findIndex(x=>!x.used&&x.key===need.key);
    if(idx<0)idx=available.findIndex(x=>!x.used&&fulfillsItem(x.name,need.name));
    if(idx>=0){available[idx].used=true;haveUnits++;}else missingNames.push(need.name);
  }
  const missing=countIngredients(missingNames);const totalUnits=needs.length;const missingUnits=missingNames.length;
  return {craftable:missingUnits===0,haveUnits,totalUnits,missingUnits,missing,ratio:totalUnits?haveUnits/totalUnits:0};
}

function recipeCard(r,status=null){
  const craftable=status?.craftable;const partial=status&&!craftable&&status.haveUnits>0;
  const readyLabel=r.type==='Blacksmith'?'Materials ready':'Craftable now';
  const progress=craftable?`<span class="chip green">${readyLabel}</span>`:partial?`<span class="chip amber">Have ${status.haveUnits}/${status.totalUnits}</span>`:'';
  const planned=state.plan.has(r.id)?'<span class="chip blue">Planned</span>':'';
  const silver=r.costSilver?`<span class="chip">${r.costSilver} silver</span>`:'';
  const missing=partial?`<div class="missing-line">Missing: ${status.missing.map(([n,c])=>`${esc(n)}${c>1?` ×${c}`:''}`).join(' · ')}</div>`:'';
  return `<article class="recipe-card ${craftable?'match':partial?'near-match':''}" data-recipe="${esc(r.id)}">
    <div class="recipe-icon">${iconFor(r.type)}</div><div class="card-main"><div class="card-title">${esc(r.name)} ×${esc(r.yield)}</div>
    <div class="meta"><span class="chip gold">${esc(r.type)}</span><span class="chip">${esc(r.station)}</span>${progress}${planned}${silver}</div>
    <div class="ingredients">${(r.ingredients||[]).map(esc).join(' · ')}</div>${missing}</div>
    <button class="save-btn ${state.saved.has(r.id)?'saved':''}" data-save="${esc(r.id)}" aria-label="${state.saved.has(r.id)?'Remove saved recipe':'Save recipe'}">${state.saved.has(r.id)?'♥':'♡'}</button>
  </article>`;
}
function getRecipeList(){
  let list=catalogRecipes.filter(r=>state.filter==='All'||r.type===state.filter);
  if(state.purpose!=='All')list=list.filter(r=>matchesPurpose(r,state.purpose));
  if(state.query.trim()){
    list=list.map(r=>({r,score:recipeSearchScore(r,state.query)}))
      .filter(x=>x.score!==Infinity)
      .sort((a,b)=>a.score-b.score||a.r.name.localeCompare(b.r.name)||a.r.station.localeCompare(b.r.station))
      .map(x=>x.r);
  }else{
    list=list.slice().sort((a,b)=>a.name.localeCompare(b.name)||a.station.localeCompare(b.station));
  }
  return list;
}
function databaseStatusHTML(){
  const count=catalogRecipes.length;
  return `<div class="database-card ready"><div><strong>Offline recipe library</strong><span>${count} recipes and blacksmith commissions are built into Aurai Companion v${APP_VERSION}. No sync required.</span></div><button id="openWikiFromDb">Wiki lookup</button></div>`;
}


function home(){
  const featured=['bandages','campfire','bread','great-astral-b'].map(getRecipe).filter(Boolean);
  return `<section class="hero"><div class="hero-kicker">Outward companion</div><h1>Find the answer without leaving the adventure.</h1>
    <p>Recipes, alchemy, ingredient matching, shopping lists, practical guides and direct Outward Wiki lookup in one phone-friendly companion.</p>
    <div class="hero-stats"><span class="hero-stat">Offline recipe library</span><span class="hero-stat">Ingredient matcher</span><span class="hero-stat">Saved on device</span></div>
    <div class="searchbox"><input id="homeSearch" placeholder="Search recipe or ingredients…" autocomplete="off"><button id="homeGo">Search</button></div></section>
  <div class="section-head"><div><h2>Quick access</h2><p>Useful while you are actually playing</p></div></div>
  <div class="quick-grid">
    <button class="quick-card" data-go="recipes" data-filter="Alchemy"><span class="emoji">⚗️</span><span class="arrow">›</span><strong>Alchemy</strong><small>Potions, charges and alchemy recipes</small></button>
    <button class="quick-card" data-go="recipes" data-filter="Cooking"><span class="emoji">🍲</span><span class="arrow">›</span><strong>Cooking</strong><small>Campfire and Cooking Pot recipes</small></button>
    <button class="quick-card" data-go="pantry"><span class="emoji">🎒</span><span class="arrow">›</span><strong>What can I make?</strong><small>Rank recipes from the ingredients you have</small></button>
    <button class="quick-card" data-go="shopping"><span class="emoji">🧾</span><span class="arrow">›</span><strong>Shopping list</strong><small>Combine missing ingredients for planned recipes</small></button>
    <button class="quick-card" data-go="compare"><span class="emoji">⚖️</span><span class="arrow">›</span><strong>Compare</strong><small>Compare two recipes side by side</small></button>
    <button class="quick-card" data-go="wiki"><span class="emoji">📖</span><span class="arrow">›</span><strong>Wiki Explorer</strong><small>Items, enemies, quests and detailed pages</small></button>
  </div>
  <div class="section-head"><div><h2>Useful recipes</h2><p>Common crafts kept instantly available</p></div><button data-go="recipes" data-filter="All">View all</button></div>
  <div class="cards grid">${featured.map(r=>recipeCard(r)).join('')}</div>
  <div class="section-head"><div><h2>Need a tip?</h2><p>Short practical guidance without wiki digging</p></div><button data-go="guides">All guides</button></div>
  <div class="cards">${D.guides.slice(0,2).map(guideCard).join('')}</div>`;
}
function recipes(){
  const shown=getRecipeList().length;
  return `<div class="page-title"><h1>Recipes</h1><p>Search by recipe, ingredient, effect, blacksmith or location. Common wording and small spelling mistakes are handled automatically.</p></div>
  ${databaseStatusHTML()}
  <div class="toolbar recipe-toolbar"><input id="recipeSearch" value="${esc(state.query)}" placeholder="Try blue sand armour crafting, water beetle, stamina…"><button id="clearRecipeSearch" class="clear-search" ${state.query?'':'hidden'} aria-label="Clear search">×</button></div>
  <div class="search-chips"><span>Try</span><button data-search-chip="blue sand armour crafting">Blue Sand armour</button><button data-search-chip="life potion">Life potion</button><button data-search-chip="water beetle">Water + beetle</button><button data-search-chip="blacksmith cierzo">Cierzo smith</button></div>
  <div class="filter-label">Recipe type</div><div class="filter-row">${['All','Survival','Cooking','Alchemy','Blacksmith','Crafting'].map(x=>`<button data-filter="${x}" class="${state.filter===x?'active':''}">${x}</button>`).join('')}</div>
  <div class="filter-label">Purpose</div><div class="filter-row purpose-row">${Object.keys(PURPOSES).map(x=>`<button data-purpose="${x}" class="${state.purpose===x?'active':''}">${x}</button>`).join('')}</div>
  <div class="notice"><strong>Already have ingredients?</strong> My Items ranks recipes by what you can make now, what is one item away and what is two items away.</div>
  <div id="recipeResultSummary" class="result-summary recipe-result-summary"><strong>${shown}</strong> matching ${shown===1?'entry':'entries'}${state.query?` <span>for</span> “${esc(state.query)}”`:''}</div>
  <div class="cards" id="recipeList">${recipeListHTML()}</div>`;
}
function recipeListHTML(){
  const list=getRecipeList();
  if(list.length)return list.map(r=>recipeCard(r)).join('');
  const q=state.query.trim();
  return `<div class="empty"><b>No offline match${q?` for “${esc(q)}”`:''}</b><span>Try fewer words, another filter, or search the current Outward Wiki.</span>${q?'<button class="primary-btn" id="recipeWikiFallback">Search Wiki</button>':''}</div>`;
}
function bindRecipeFallback(scope=document){
  const b=scope.querySelector?.('#recipeWikiFallback');
  if(b)b.onclick=()=>{state.wikiQuery=state.query.trim();setRoute('wiki');setTimeout(()=>searchWiki(state.wikiQuery),0);};
}
function ingredientSuggestionHTML(raw){const list=ingredientSearchMatches(raw);return list.length?list.map(x=>`<button data-ingredient-suggestion="${esc(x.name)}"><strong>${esc(x.name)}</strong><small>tap to add</small></button>`).join(''):raw.trim()?'<span>No close ingredient names found — you can still add exactly what you typed.</span>':'';}

function loadoutsInlineHTML(){
  if(!state.loadouts.length)return '';
  return `<div class="loadout-strip">${state.loadouts.slice(0,5).map(l=>`<button data-load-loadout="${esc(l.id)}">${esc(l.name)} <small>${l.items.length}</small></button>`).join('')}</div>`;
}
function pantry(){
  const grouped={};state.pantry.forEach(item=>{const k=canon(item);if(!grouped[k])grouped[k]={key:k,name:ingredientByKey.get(k)||item,count:0};grouped[k].count++;});
  const pool=catalogRecipes.filter(r=>state.pantryType==='All'||r.type===state.pantryType);
  const statuses=pool.map(r=>({r,s:pantryStatus(r)}));
  const filterByPantryQuery=x=>!state.pantryQuery.trim()||matchesTerms(x.r,state.pantryQuery);
  const filtered=statuses.filter(filterByPantryQuery);
  const craftable=filtered.filter(x=>x.s.craftable).sort((a,b)=>a.r.name.localeCompare(b.r.name));
  const oneAway=filtered.filter(x=>!x.s.craftable&&x.s.haveUnits>0&&x.s.missingUnits===1).sort((a,b)=>b.s.ratio-a.s.ratio||a.r.name.localeCompare(b.r.name));
  const twoAway=filtered.filter(x=>!x.s.craftable&&x.s.haveUnits>0&&x.s.missingUnits===2).sort((a,b)=>b.s.ratio-a.s.ratio||a.r.name.localeCompare(b.r.name));
  const more=filtered.filter(x=>!x.s.craftable&&x.s.haveUnits>0&&x.s.missingUnits>2).sort((a,b)=>a.s.missingUnits-b.s.missingUnits||b.s.ratio-a.s.ratio||a.r.name.localeCompare(b.r.name));
  const common=['Water','Clean Water','Linen Cloth','Wood','Salt','Raw Meat','Thick Oil','Blue Sand'].filter(x=>ingredientByKey.has(canon(x)));
  return `<div class="page-title"><h1>My Items</h1><p>Add what is in your bag and Aurai will rank the most useful matches first. You can enter several ingredients at once.</p></div>
  <div class="pantry-action-row"><button id="saveLoadout" ${!state.pantry.length?'disabled':''}>Save loadout</button><button id="manageLoadouts">Loadouts ${state.loadouts.length?`(${state.loadouts.length})`:''}</button><button data-go="shopping">Shopping ${state.plan.size?`(${state.plan.size})`:''}</button></div>
  ${loadoutsInlineHTML()}
  <div class="pantry-add"><input id="pantryInput" placeholder="Water, Salt, Livweedi or 3x Blue Sand" autocomplete="off"><button class="primary-btn" id="pantryAdd">Add</button></div>
  <div class="pantry-help">Separate several items with commas or new lines. Quantities such as <strong>3x Blue Sand</strong> are supported.</div>
  <div class="ingredient-suggestions" id="ingredientSuggestions"></div>
  ${common.length?`<div class="quick-ingredients"><span>Quick add</span>${common.map(i=>`<button data-quick-ingredient="${esc(i)}">+ ${esc(i)}</button>`).join('')}</div>`:''}
  <div class="pantry-list">${state.pantry.length?Object.values(grouped).map(g=>`<span class="pantry-pill"><button class="qty-btn" data-pantry-dec="${encodeURIComponent(g.key)}" aria-label="Remove one ${esc(g.name)}">−</button><button class="ingredient-name-btn" data-ingredient-open="${esc(g.name)}">${esc(g.name)}${g.count>1?` ×${g.count}`:''}</button><button class="qty-btn plus" data-pantry-inc="${encodeURIComponent(g.key)}" aria-label="Add another ${esc(g.name)}">+</button></span>`).join(''):'<span class="chip">No items added yet</span>'}</div>
  ${state.pantry.length?`<div class="filter-label">Show results from</div><div class="filter-row pantry-type-row">${['All','Survival','Cooking','Alchemy','Blacksmith'].map(x=>`<button data-pantry-type="${x}" class="${state.pantryType===x?'active':''}">${x}</button>`).join('')}</div>
  <div class="pantry-tools"><input id="pantryRecipeSearch" value="${esc(state.pantryQuery)}" placeholder="Filter matching recipes…"><button id="clearPantry">Clear items</button></div>`:''}
  ${state.pantry.length?`<div class="result-summary"><strong>${craftable.length}</strong> ready <span>·</span> <strong>${oneAway.length}</strong> one item away <span>·</span> <strong>${twoAway.length}</strong> two away</div>`:'<div class="notice"><strong>Try it:</strong> add two or three ingredients. Aurai will show exact recipes first and then the closest options.</div>'}
  ${state.pantry.length?`
  <div class="section-head"><div><h2>Ready now</h2><p>Everything required is already in My Items</p></div></div><div class="cards">${craftable.length?craftable.slice(0,80).map(x=>recipeCard(x.r,x.s)).join(''):'<div class="empty">Nothing complete yet.</div>'}</div>
  <div class="section-head"><div><h2>Missing one item</h2><p>The fastest recipes to finish</p></div></div><div class="cards">${oneAway.length?oneAway.slice(0,60).map(x=>recipeCard(x.r,x.s)).join(''):'<div class="empty">No one-item-away matches yet.</div>'}</div>
  <div class="section-head"><div><h2>Missing two items</h2><p>Still close to what is already in your bag</p></div></div><div class="cards">${twoAway.length?twoAway.slice(0,60).map(x=>recipeCard(x.r,x.s)).join(''):'<div class="empty">No two-item-away matches yet.</div>'}</div>
  ${more.length?`<details class="more-matches"><summary>More related recipes <span>${more.length}</span></summary><div class="cards">${more.slice(0,60).map(x=>recipeCard(x.r,x.s)).join('')}</div></details>`:''}`:''}`;
}

function shoppingSummary(){
  const recipes=[...state.plan].map(getRecipe).filter(Boolean);const needed=[];recipes.forEach(r=>needed.push(...r.ingredients));
  const inventory=[...state.pantry];const available=inventory.map(name=>({name,key:canon(name),used:false}));const missing=[];
  const needs=needed.map(name=>({name,key:canon(name),generic:GENERIC_INGREDIENTS.has(canon(name))})).sort((a,b)=>Number(a.generic)-Number(b.generic));
  for(const need of needs){let idx=available.findIndex(x=>!x.used&&x.key===need.key);if(idx<0)idx=available.findIndex(x=>!x.used&&fulfillsItem(x.name,need.name));if(idx>=0)available[idx].used=true;else missing.push(need.name);}
  const silver=recipes.reduce((sum,r)=>sum+(Number(r.costSilver)||0),0);
  return {recipes,missing:countIngredients(missing),needed:countIngredients(needed),silver};
}
function shopping(){
  const s=shoppingSummary();
  return `<div class="page-title"><h1>Shopping List</h1><p>Plan recipes and Aurai combines what you still need after checking My Items.</p></div>
  ${!s.recipes.length?'<div class="empty large-empty"><b>No recipes planned yet</b><span>Open any recipe and tap “Add to shopping list”.</span><button data-go="recipes" class="primary-btn">Browse recipes</button></div>':`<div class="shopping-summary"><div><strong>${s.recipes.length}</strong><span>planned recipes</span></div><div><strong>${s.missing.reduce((n,[,c])=>n+c,0)}</strong><span>materials missing</span></div>${s.silver?`<div><strong>${s.silver}</strong><span>silver for commissions</span></div>`:''}</div>
  <div class="section-head"><div><h2>Still needed</h2><p>Combined across every planned recipe</p></div><button id="copyShopping">Copy list</button></div>
  <div class="shopping-list">${s.missing.length?s.missing.map(([name,count])=>`<button data-ingredient-open="${esc(name)}"><span>${esc(name)}</span><strong>×${count}</strong></button>`).join(''):'<div class="notice success-note"><strong>You already have everything in My Items.</strong></div>'}</div>
  <div class="section-head"><div><h2>Planned recipes</h2><p>Tap a recipe for details</p></div><button id="clearPlan">Clear all</button></div><div class="cards">${s.recipes.map(r=>recipeCard(r,pantryStatus(r))).join('')}</div>`}`;
}

function compareRecipePanel(r){
  if(!r)return '<div class="compare-empty">Choose a recipe above.</div>';
  const status=state.pantry.length?pantryStatus(r):null;
  return `<div class="compare-panel"><div class="recipe-icon">${iconFor(r.type)}</div><h3>${esc(r.name)}</h3><div class="meta"><span class="chip gold">${esc(r.type)}</span><span class="chip">${esc(r.station)}</span></div>
    <dl><dt>Makes</dt><dd>${esc(r.yield)}</dd><dt>${r.type==='Blacksmith'?'Materials':'Ingredients'}</dt><dd>${countIngredients(r.ingredients).map(([n,c])=>`${esc(n)}${c>1?` ×${c}`:''}`).join('<br>')}</dd>${r.costSilver?`<dt>Commission</dt><dd>${r.costSilver} silver</dd>`:''}<dt>Use / tags</dt><dd>${(r.tags||[]).length?(r.tags||[]).map(esc).join(' · '):esc(r.note||'No quick-use tags in the recipe index')}</dd>${status?`<dt>My Items</dt><dd>${status.craftable?'Ready to make':`Have ${status.haveUnits}/${status.totalUnits}`}</dd>`:''}</dl>
    <button data-recipe="${esc(r.id)}" class="secondary-btn compare-open">Open recipe</button></div>`;
}
function compare(){
  const options=catalogRecipes.map(r=>`<option value="${esc(r.id)}">${esc(r.name)} — ${esc(r.station)}</option>`).join('');
  const a=getRecipe(state.compareA),b=getRecipe(state.compareB);
  return `<div class="page-title"><h1>Compare Recipes</h1><p>Useful when two recipes make similar items or compete for the same ingredients.</p></div>
  <div class="compare-selects"><label>Recipe A<select id="compareA"><option value="">Choose recipe…</option>${options}</select></label><label>Recipe B<select id="compareB"><option value="">Choose recipe…</option>${options}</select></label></div>
  <div class="compare-grid">${compareRecipePanel(a)}${compareRecipePanel(b)}</div>`;
}

function guideCard(g){return `<article class="guide-card"><h3>${g.icon} ${esc(g.title)}</h3><p>${esc(g.text)}</p>${g.points?.length?`<ul>${g.points.map(p=>`<li>${esc(p)}</li>`).join('')}</ul>`:''}</article>`;}
function guides(){return `<div class="page-title"><h1>Field Guides</h1><p>Short practical notes for decisions that come up often during a run.</p></div><div class="cards">${D.guides.map(guideCard).join('')}</div><div class="notice" style="margin-top:14px">For exact mechanics and unusual cases, use Wiki Explorer to open the current Outward Wiki article.</div>`;}
function saved(){const list=catalogRecipes.filter(r=>state.saved.has(r.id));return `<div class="page-title"><h1>Saved</h1><p>Favourite recipes are stored on this device.</p></div><div class="cards">${list.length?list.map(r=>recipeCard(r)).join(''):'<div class="empty">Tap ♡ on a recipe to keep it here.</div>'}</div>`;}

function settings(){
  const savedCount=state.saved.size, pantryCount=state.pantry.length, planCount=state.plan.size, loadoutCount=state.loadouts.length;
  return `<div class="page-title"><h1>Settings & Data</h1><p>Version information, local data backup and maintenance tools in one place.</p></div>
  <div class="settings-version"><div class="settings-appmark"><img src="icon.svg" alt=""><div><strong>Aurai Companion</strong><span>Version ${APP_VERSION}</span></div></div><span class="status-pill ${navigator.onLine?'online':'offline'}">${navigator.onLine?'Online':'Offline'}</span></div>
  <div class="settings-grid">
    <div class="settings-stat"><strong>${catalogRecipes.length}</strong><span>offline recipe entries</span></div>
    <div class="settings-stat"><strong>${savedCount}</strong><span>saved recipes</span></div>
    <div class="settings-stat"><strong>${pantryCount}</strong><span>items in My Items</span></div>
    <div class="settings-stat"><strong>${loadoutCount}</strong><span>saved loadouts</span></div>
  </div>
  <section class="settings-card"><h2>Backup & restore</h2><p>Your favourites, My Items, shopping list, loadouts and recent wiki searches are stored only on this device. Copy or download a backup before changing phones or reinstalling.</p><div class="settings-actions"><button class="primary-btn" id="copyBackup">Copy backup</button><button class="secondary-btn" id="downloadBackup">Download JSON</button></div><button class="secondary-btn full-btn" id="importBackup">Import backup</button></section>
  <section class="settings-card"><h2>Offline library</h2><p>The recipe and blacksmith library ships inside the app. There is no live recipe sync, so the app stays useful without internet and cannot be broken by wiki API changes.</p><div class="settings-actions"><button class="secondary-btn" data-go="recipes">Browse library</button><button class="secondary-btn" id="clearLegacyDb">Clear old sync cache</button></div></section>
  <section class="settings-card"><h2>App maintenance</h2><p>APK updates are built from your GitHub repository. Reset only if you deliberately want to erase your saved app data.</p><div class="settings-actions"><button class="secondary-btn" id="openGithub">Open GitHub project</button><button class="danger-btn" id="resetAppData">Reset local data</button></div><small>Shopping list: ${planCount} planned recipe${planCount===1?'':'s'}.</small></section>`;
}

const wikiAreas=[['⚗️','Alchemy','Alchemy'],['🍲','Cooking','Cooking'],['⚔️','Weapons','Weapons'],['🛡️','Equipment','Equipment'],['👹','Enemies','Enemies'],['🗺️','Locations','Locations'],['📜','Quests','Quests'],['✨','Skills','Skills'],['🔮','Enchantments','Enchantments']];
function wiki(){
  return `<div class="page-title"><h1>Wiki Explorer</h1><p>Search Aurai's offline library first, then jump to the full Outward Wiki when you need quests, enemies, locations or deeper details.</p></div>
  <div class="searchbox"><input id="wikiSearch" value="${esc(state.wikiQuery)}" placeholder="Potion, enemy, quest, item…"><button id="wikiGo">Search</button></div>
  <div class="wiki-categories">${wikiAreas.map(a=>`<button data-wiki-page="${esc(a[2])}"><b>${a[0]}</b><span>${esc(a[1])}</span></button>`).join('')}</div>
  <div class="notice"><strong>Reliable by design:</strong> Aurai does not depend on the wiki API. Offline recipe matches are shown here; full wiki searches open directly in outward.wiki.gg when online.</div>
  <div id="wikiResults" class="cards">${recentWikiHTML()}</div>`;
}
function recentWikiHTML(){if(!state.recentWiki.length)return '<div class="empty">Search above, or choose a category to open the wiki.</div>';return `<div class="section-head" style="margin-top:2px"><div><h2>Recent lookups</h2><p>Stored only on this device</p></div></div>${state.recentWiki.map((q,i)=>`<article class="wiki-card" data-recent-wiki="${esc(q)}"><div class="wiki-index">${i+1}</div><a href="#"><h3>${esc(q)}</h3><p>Search the Outward Wiki again</p></a></article>`).join('')}`;}

function render(){
  const views={home,recipes,pantry,shopping,compare,wiki,guides,saved,settings};
  app.innerHTML=(views[state.route]||home)();app.setAttribute('aria-label',routeTitle(state.route));
  $$('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.route===state.route));renderDrawer();bindView();
  if(state.route==='compare'){const a=$('#compareA'),b=$('#compareB');if(a)a.value=state.compareA||'';if(b)b.value=state.compareB||'';}
}
function renderDrawer(){
  const nav=$('#drawerNav');
  nav.innerHTML=[['home','⌂','Home'],['recipes','⚗','Recipes'],['pantry','🎒','My Items'],['shopping','🧾','Shopping List'],['compare','⚖','Compare'],['wiki','📖','Wiki Explorer'],['guides','✦','Field Guides'],['saved','♡','Saved'],['settings','⚙','Settings & Data']].map(([r,i,n])=>`<button data-drawer-route="${r}" class="${state.route===r?'active':''}">${i}&nbsp;&nbsp;${n}</button>`).join('');
  $$('[data-drawer-route]').forEach(b=>b.onclick=()=>setRoute(b.dataset.drawerRoute));
}
function setRoute(route,push=true){
  if(!allowedRoutes.has(route))route='home';state.route=route;closeDrawer();closeSheet();haptic();render();
  if(push&&location.protocol!=='file:'){const u=new URL(location.href);if(route==='home')u.searchParams.delete('route');else u.searchParams.set('route',route);history.pushState({route},'',u);}
  requestAnimationFrame(()=>window.scrollTo({top:0,behavior:'smooth'}));
}
function bindRecipeCards(root=document){
  root.querySelectorAll('[data-recipe]').forEach(el=>el.onclick=e=>{if(e.target.closest('[data-save]'))return;openRecipe(el.dataset.recipe);});
  root.querySelectorAll('[data-save]').forEach(el=>el.onclick=e=>{e.stopPropagation();toggleSave(el.dataset.save);});
}
function bindView(){
  $$('[data-go]').forEach(el=>el.onclick=()=>{if(el.dataset.filter){state.filter=el.dataset.filter;state.query='';state.purpose='All';}setRoute(el.dataset.go);});
  $$('.filter-row [data-filter]').forEach(el=>el.onclick=()=>{state.filter=el.dataset.filter;render();});
  $$('[data-purpose]').forEach(el=>el.onclick=()=>{state.purpose=el.dataset.purpose;render();});
  bindRecipeCards();

  const rs=$('#recipeSearch');if(rs)rs.oninput=e=>{state.query=e.target.value;const list=$('#recipeList');if(list){list.innerHTML=recipeListHTML();bindRecipeCards(list);bindRecipeFallback(list);}const clear=$('#clearRecipeSearch');if(clear)clear.hidden=!state.query;const sum=$('#recipeResultSummary');if(sum){const n=getRecipeList().length;sum.innerHTML=`<strong>${n}</strong> matching ${n===1?'entry':'entries'}${state.query?` <span>for</span> “${esc(state.query)}”`:''}`;}};
  const crs=$('#clearRecipeSearch');if(crs)crs.onclick=()=>{state.query='';render();requestAnimationFrame(()=>$('#recipeSearch')?.focus());};
  $$('[data-search-chip]').forEach(b=>b.onclick=()=>{state.query=b.dataset.searchChip;state.filter='All';state.purpose='All';render();});
  const hs=$('#homeSearch'),hg=$('#homeGo');if(hg)hg.onclick=()=>{state.query=hs.value;state.filter='All';state.purpose='All';setRoute('recipes');};if(hs)hs.onkeydown=e=>{if(e.key==='Enter')hg.click();};
  const dbWiki=$('#openWikiFromDb');if(dbWiki)dbWiki.onclick=()=>setRoute('wiki');bindRecipeFallback();

  const pa=$('#pantryAdd'),pi=$('#pantryInput');if(pa)pa.onclick=()=>addPantry(pi.value);if(pi){pi.onkeydown=e=>{if(e.key==='Enter')pa.click();};pi.oninput=e=>{state.ingredientQuery=e.target.value;const box=$('#ingredientSuggestions');if(box)box.innerHTML=ingredientSuggestionHTML(state.ingredientQuery);bindIngredientSuggestions();};}
  bindIngredientSuggestions();
  $$('[data-quick-ingredient]').forEach(b=>b.onclick=()=>addPantry(b.dataset.quickIngredient));
  $$('[data-pantry-inc]').forEach(b=>b.onclick=()=>changePantry(decodeURIComponent(b.dataset.pantryInc),1));
  $$('[data-pantry-dec]').forEach(b=>b.onclick=()=>changePantry(decodeURIComponent(b.dataset.pantryDec),-1));
  $$('[data-pantry-type]').forEach(b=>b.onclick=()=>{state.pantryType=b.dataset.pantryType;render();});
  $$('[data-ingredient-open]').forEach(b=>b.onclick=()=>openIngredient(b.dataset.ingredientOpen));
  const cp=$('#clearPantry');if(cp)cp.onclick=()=>{state.pantry=[];state.pantryQuery='';saveState();render();toast('Items cleared');};
  const prs=$('#pantryRecipeSearch');if(prs)prs.oninput=e=>{state.pantryQuery=e.target.value;render();requestAnimationFrame(()=>{const input=$('#pantryRecipeSearch');if(input){input.focus();input.setSelectionRange(input.value.length,input.value.length);}});};
  const sl=$('#saveLoadout');if(sl)sl.onclick=saveLoadoutSheet;const ml=$('#manageLoadouts');if(ml)ml.onclick=openLoadoutsSheet;$$('[data-load-loadout]').forEach(b=>b.onclick=()=>loadLoadout(b.dataset.loadLoadout));

  const clearPlan=$('#clearPlan');if(clearPlan)clearPlan.onclick=()=>{state.plan.clear();saveState();render();toast('Shopping list cleared');};
  const copy=$('#copyShopping');if(copy)copy.onclick=copyShoppingList;

  const ca=$('#compareA'),cb=$('#compareB');if(ca)ca.onchange=e=>{state.compareA=e.target.value;saveState();render();};if(cb)cb.onchange=e=>{state.compareB=e.target.value;saveState();render();};

  const wg=$('#wikiGo'),ws=$('#wikiSearch');if(wg)wg.onclick=()=>searchWiki(ws.value);if(ws)ws.onkeydown=e=>{if(e.key==='Enter')wg.click();};
  $$('[data-wiki-page]').forEach(b=>b.onclick=()=>openExternal(wikiURL(b.dataset.wikiPage)));$$('[data-recent-wiki]').forEach(c=>c.onclick=e=>{e.preventDefault();searchWiki(c.dataset.recentWiki);});

  const copyBackupBtn=$('#copyBackup');if(copyBackupBtn)copyBackupBtn.onclick=async()=>toast(await copyText(backupText())?'Backup copied':'Could not copy backup');
  const downloadBackupBtn=$('#downloadBackup');if(downloadBackupBtn)downloadBackupBtn.onclick=()=>{const ok=downloadTextFile(`aurai-companion-backup-${new Date().toISOString().slice(0,10)}.json`,backupText());toast(ok?'Backup downloaded':'Download unavailable — use Copy backup');};
  const importBackupBtn=$('#importBackup');if(importBackupBtn)importBackupBtn.onclick=openImportBackupSheet;
  const clearLegacyDb=$('#clearLegacyDb');if(clearLegacyDb)clearLegacyDb.onclick=()=>{deleteLegacyRecipeCache();localStorage.setItem('auraiLegacyDbCleared','1');toast('Old recipe sync cache cleared');};
  const openGithub=$('#openGithub');if(openGithub)openGithub.onclick=()=>openExternal('https://github.com/Broseppe/Aurai-Companion');
  const resetAppData=$('#resetAppData');if(resetAppData)resetAppData.onclick=openResetDataSheet;
}
function bindIngredientSuggestions(){
  $$('[data-ingredient-suggestion]').forEach(b=>b.onclick=()=>{const input=$('#pantryInput');if(input)input.value=b.dataset.ingredientSuggestion;addPantry(b.dataset.ingredientSuggestion);});
}
function parsePantryEntries(value){
  return String(value||'').split(/[\n,;]+/).map(x=>x.trim()).filter(Boolean).flatMap(raw=>{
    let name=raw,count=1;
    let m=raw.match(/^\s*(\d{1,3})\s*[x×]\s*(.+)$/i);
    if(m){count=Math.max(1,Math.min(99,Number(m[1])||1));name=m[2].trim();}
    else{
      m=raw.match(/^(.+?)\s*[x×]\s*(\d{1,3})\s*$/i);
      if(m){name=m[1].trim();count=Math.max(1,Math.min(99,Number(m[2])||1));}
    }
    const normalized=normalizeIngredient(name);
    return Array.from({length:count},()=>normalized);
  });
}
function addPantry(value){
  const raw=String(value||'').trim();if(!raw)return toast('Enter an ingredient');
  const entries=parsePantryEntries(raw);if(!entries.length)return toast('No ingredients found');
  state.pantry.push(...entries);saveState();haptic();render();
  toast(entries.length===1?`Added ${entries[0]}`:`Added ${entries.length} items`);
  requestAnimationFrame(()=>$('#pantryInput')?.focus());
}
function changePantry(key,delta){
  if(delta>0)state.pantry.push(ingredientByKey.get(key)||key);else{const idx=state.pantry.map(canon).lastIndexOf(key);if(idx>=0)state.pantry.splice(idx,1);}saveState();haptic();render();
}
function toggleSave(id){if(state.saved.has(id)){state.saved.delete(id);toast('Removed from saved');}else{state.saved.add(id);toast('Saved recipe');}saveState();haptic();render();}
function togglePlan(id){if(state.plan.has(id)){state.plan.delete(id);toast('Removed from shopping list');}else{state.plan.add(id);toast('Added to shopping list');}saveState();haptic();}

function openImportBackupSheet(){
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">Settings & Data</div><h2>Import backup</h2></div></div><p class="sheet-copy">Paste a JSON backup created by Aurai Companion. Importing replaces the current saved recipes, My Items, shopping list and loadouts.</p><textarea class="backup-textarea" id="backupImportText" placeholder="Paste Aurai Companion backup JSON here…" spellcheck="false"></textarea><button class="primary-btn full-btn" id="confirmImportBackup">Import backup</button>`);
  $('#confirmImportBackup').onclick=()=>{try{const payload=JSON.parse($('#backupImportText').value.trim());applyBackupPayload(payload);closeSheet();render();toast('Backup restored');}catch(err){toast(err?.message||'Could not import backup');}};
  requestAnimationFrame(()=>$('#backupImportText')?.focus());
}
function openResetDataSheet(){
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">Settings & Data</div><h2>Reset local data?</h2></div></div><p class="sheet-copy">This clears favourites, My Items, shopping list, loadouts, comparison choices and recent searches. The built-in recipe library is not removed.</p><div class="actions"><button class="secondary-btn" data-close-sheet>Cancel</button><button class="danger-btn" id="confirmResetData">Reset data</button></div>`);
  $('#infoSheetContent [data-close-sheet]')?.addEventListener('click',closeSheet);
  $('#confirmResetData').onclick=()=>{['auraiSaved','auraiPantry','auraiPlan','auraiLoadouts','auraiRecentWiki','auraiCompareA','auraiCompareB'].forEach(k=>localStorage.removeItem(k));state.saved.clear();state.pantry=[];state.plan.clear();state.loadouts=[];state.recentWiki=[];state.compareA='';state.compareB='';deleteLegacyRecipeCache();closeSheet();render();toast('Local app data reset');};
}

function saveLoadoutSheet(){
  if(!state.pantry.length)return toast('Add some items first');
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">My Items</div><h2>Save loadout</h2></div></div><p class="sheet-copy">Keep this ingredient setup so you can restore it later.</p><input class="sheet-input" id="loadoutName" placeholder="e.g. Cierzo supply run" maxlength="40"><button class="primary-btn full-btn" id="confirmLoadout">Save loadout</button>`);
  requestAnimationFrame(()=>$('#loadoutName')?.focus());$('#confirmLoadout').onclick=()=>{const name=$('#loadoutName').value.trim()||`Loadout ${state.loadouts.length+1}`;state.loadouts.unshift({id:`l-${Date.now().toString(36)}`,name,items:[...state.pantry],createdAt:Date.now()});state.loadouts=state.loadouts.slice(0,12);saveState();closeSheet();render();toast('Loadout saved');};
}
function openLoadoutsSheet(){
  const html=state.loadouts.length?state.loadouts.map(l=>`<div class="loadout-row"><button data-sheet-load="${esc(l.id)}"><strong>${esc(l.name)}</strong><small>${l.items.length} items</small></button><button class="delete-mini" data-delete-loadout="${esc(l.id)}" aria-label="Delete ${esc(l.name)}">×</button></div>`).join(''):'<div class="empty">No saved loadouts yet.</div>';
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">My Items</div><h2>Saved loadouts</h2></div></div>${html}`);
  $$('[data-sheet-load]').forEach(b=>b.onclick=()=>{closeSheet();loadLoadout(b.dataset.sheetLoad);});$$('[data-delete-loadout]').forEach(b=>b.onclick=()=>{state.loadouts=state.loadouts.filter(l=>l.id!==b.dataset.deleteLoadout);saveState();closeSheet();openLoadoutsSheet();});
}
function loadLoadout(id){const l=state.loadouts.find(x=>x.id===id);if(!l)return;state.pantry=[...l.items];saveState();render();toast(`Loaded ${l.name}`);}
async function copyShoppingList(){
  const s=shoppingSummary();
  const lines=s.missing.length?s.missing.map(([n,c])=>`${n} x${c}`):['No materials missing — My Items covers every planned recipe.'];
  if(s.silver)lines.push('',`Commission cost: ${s.silver} silver`);
  const text=lines.join('\n');
  try{await navigator.clipboard.writeText(text);toast('Shopping list copied');}catch{if(navigator.share){try{await navigator.share({title:'Aurai Companion shopping list',text});}catch{}}else toast('Could not copy list');}
}

function showSheet(html){$('#infoSheetContent').innerHTML=html;$('#infoSheet').classList.add('open');$('#infoSheet').setAttribute('aria-hidden','false');$('#sheetBackdrop').classList.add('show');document.body.style.overflow='hidden';}
function closeSheet(){$('#infoSheet').classList.remove('open');$('#infoSheet').setAttribute('aria-hidden','true');$('#sheetBackdrop').classList.remove('show');document.body.style.overflow='';}
function openIngredient(name){
  const matches=catalogRecipes.filter(r=>(r.ingredients||[]).some(i=>canon(i)===canon(name))).slice(0,30);
  const current=state.pantry.filter(i=>canon(i)===canon(name)).length;
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">Ingredient</div><h2>${esc(name)}</h2><div class="meta"><span class="chip">${matches.length} recipe${matches.length===1?'':'s'}</span>${current?`<span class="chip green">In My Items ×${current}</span>`:''}</div></div></div>
    <div class="actions"><button class="primary-btn" id="ingredientAdd">+ Add to My Items</button><button class="secondary-btn" id="ingredientWiki">Open Wiki</button></div>
    <div class="detail-block"><h3>Recipes using it</h3><div class="ingredient-uses">${matches.length?matches.map(r=>`<button data-sheet-recipe="${esc(r.id)}"><span>${iconFor(r.type)} ${esc(r.name)}</span><small>${esc(r.station)}</small></button>`).join(''):'<div class="empty">No recipe in the current index uses this exact ingredient name.</div>'}</div></div>`);
  $('#ingredientAdd').onclick=()=>{state.pantry.push(normalizeIngredient(name));saveState();toast(`Added ${name}`);closeSheet();if(state.route==='pantry')render();};$('#ingredientWiki').onclick=()=>openExternal(wikiURL(name));
  $$('[data-sheet-recipe]').forEach(b=>b.onclick=()=>openRecipe(b.dataset.sheetRecipe));
}
function openRecipe(id){
  const r=getRecipe(id);if(!r)return;const status=state.pantry.length?pantryStatus(r):null;
  const pantryNote=status?status.craftable?`<div class="notice success-note"><strong>${r.type==='Blacksmith'?'Materials ready':'Ready to make'}:</strong> you have all required materials in My Items.${r.costSilver?` You will also need ${r.costSilver} silver.`:''}</div>`:status.haveUnits?`<div class="notice"><strong>From My Items:</strong> you have ${status.haveUnits}/${status.totalUnits}. Missing ${status.missing.map(([n,c])=>`${esc(n)}${c>1?` ×${c}`:''}`).join(', ')}.</div>`:'' :'';
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">${esc(r.type)} · ${esc(r.station)}</div><h2>${esc(r.name)}</h2><div class="meta"><span class="chip gold">Makes ${esc(r.yield)}</span>${(r.tags||[]).slice(0,4).map(t=>`<span class="chip">${esc(t)}</span>`).join('')}${r.source==='wiki-index'?'<span class="chip blue">Offline index</span>':''}</div></div></div>
    <div class="detail-block"><h3>${r.type==='Blacksmith'?'Materials':'Ingredients'}</h3><div class="ingredient-list">${countIngredients(r.ingredients).map(([name,count])=>`<button class="ingredient-row ingredient-link" data-ingredient-open="${esc(name)}"><span>${esc(name)}</span><strong>×${count} ›</strong></button>`).join('')}</div></div>${r.costSilver?`<div class="notice"><strong>Commission cost:</strong> ${r.costSilver} silver</div>`:''}${pantryNote}
    ${r.note?`<div class="detail-block"><h3>Quick note</h3><div class="notice">${esc(r.note)}</div></div>`:''}
    <div class="actions"><button class="secondary-btn" id="sheetSave">${state.saved.has(r.id)?'♥ Saved':'♡ Save'}</button><button class="primary-btn" id="sheetWiki">Open Wiki</button></div>
    <div class="actions"><button class="secondary-btn" id="sheetPlan">${state.plan.has(r.id)?'✓ In shopping list':'＋ Shopping list'}</button><button class="secondary-btn" id="sheetCompare">⚖ Compare</button></div>
    ${navigator.share?'<div class="actions"><button class="secondary-btn" id="sheetShare">Share recipe</button></div>':''}`);
  $('#sheetSave').onclick=()=>{toggleSave(r.id);closeSheet();};$('#sheetWiki').onclick=()=>openExternal(wikiURL(r.wiki||r.name));$('#sheetPlan').onclick=()=>{togglePlan(r.id);closeSheet();render();};
  $('#sheetCompare').onclick=()=>{if(!state.compareA||state.compareA===r.id)state.compareA=r.id;else state.compareB=r.id;saveState();closeSheet();setRoute('compare');};
  $$('[data-ingredient-open]').forEach(b=>b.onclick=()=>openIngredient(b.dataset.ingredientOpen));
  const share=$('#sheetShare');if(share)share.onclick=async()=>{try{await navigator.share({title:`${r.name} — Aurai Companion`,text:`${r.name}: ${r.ingredients.join(', ')}`,url:wikiURL(r.wiki||r.name)});}catch{}};
}

async function searchWiki(raw){
  const q=String(raw||'').trim();if(!q)return toast('Enter something to search');
  state.wikiQuery=q;state.recentWiki=[q,...state.recentWiki.filter(x=>x.toLowerCase()!==q.toLowerCase())].slice(0,6);saveState();
  const target=$('#wikiResults');if(!target)return;
  const matches=catalogRecipes.map(r=>({r,score:recipeSearchScore(r,q)})).filter(x=>x.score!==Infinity).sort((a,b)=>a.score-b.score||a.r.name.localeCompare(b.r.name)).slice(0,8).map(x=>x.r);
  target.innerHTML=`<div class="wiki-local-head"><div><strong>${matches.length?`${matches.length} offline match${matches.length===1?'':'es'}`:'No offline match'}</strong><span>Aurai checks its built-in recipe library before opening the web.</span></div><button class="primary-btn" id="wikiFullSearch">Search full Wiki</button></div>${matches.length?matches.map(r=>recipeCard(r)).join(''):`<div class="empty"><b>No recipe match for “${esc(q)}”</b><span>The full Outward Wiki may still have an item, quest, enemy or location with that name.</span></div>`}`;
  bindRecipeCards(target);
  $('#wikiFullSearch').onclick=()=>openExternal(`${WIKI}/index.php?search=${encodeURIComponent(q)}`);
}

function openDrawer(){$('#drawer').classList.add('open');$('#drawer').setAttribute('aria-hidden','false');$('#backdrop').classList.add('show');}
function closeDrawer(){$('#drawer').classList.remove('open');$('#drawer').setAttribute('aria-hidden','true');$('#backdrop').classList.remove('show');}
function installSheetHTML(){
  if(IS_NATIVE)return `<div class="install-card"><img src="icon.svg" alt=""><h2>Aurai Companion</h2><p>The Android app is installed and ready to use.</p><div class="install-steps"><div><span class="step-num">✓</span><span>Recipes, My Items, saved recipes, loadouts and shopping lists stay on this phone.</span></div><div><span class="step-num">✓</span><span>The recipe and blacksmith database is included in the app and works offline.</span></div></div><small>Version ${APP_VERSION}</small></div>`;
  if(IS_STANDALONE)return `<div class="install-card"><img src="icon.svg" alt=""><h2>Already installed</h2><p>Aurai Companion is running in standalone app mode.</p><div class="install-steps"><div><span class="step-num">✓</span><span>Launch it from your home screen or app drawer.</span></div><div><span class="step-num">✓</span><span>Hosted web updates are checked automatically.</span></div></div><small>Version ${APP_VERSION}</small></div>`;
  if(deferredInstallPrompt)return `<div class="install-card"><img src="icon.svg" alt=""><h2>Install Aurai Companion</h2><p>Add it to this phone so it opens like a normal app.</p><div class="install-steps"><div><span class="step-num">1</span><span>Tap <strong>Install now</strong>.</span></div><div><span class="step-num">2</span><span>Confirm the browser install prompt.</span></div></div><button class="primary-btn" id="installNow" style="width:100%">Install now</button></div>`;
  const isiOS=/iphone|ipad|ipod/i.test(navigator.userAgent);return `<div class="install-card"><img src="icon.svg" alt=""><h2>Install on this phone</h2><p>${isiOS?'Safari installs web apps from the Share menu.':'Open the browser menu and choose Install app or Add to Home screen.'}</p><small>Version ${APP_VERSION}</small></div>`;
}
function showInstallSheet(){showSheet(installSheetHTML());const btn=$('#installNow');if(btn)btn.onclick=async()=>{try{await deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;closeSheet();}catch{toast('Install prompt unavailable');}};}
function updateNetworkLabel(){const l=$('#networkLabel');if(!l)return;l.textContent=`${navigator.onLine?'Online':'Offline'} · v${APP_VERSION}`;l.className=navigator.onLine?'online':'offline';}
function showUpdate(){if(IS_NATIVE)return;const bar=$('#updateBar');if(bar)bar.hidden=false;}
function hideUpdate(){const bar=$('#updateBar');if(bar)bar.hidden=true;}
async function checkForUpdate(){if(IS_NATIVE)return toast('APK updates come from your GitHub build');if(!swRegistration)return toast('Update checks need the hosted web version');try{await swRegistration.update();toast(swRegistration.waiting?'Update ready':'You’re up to date');if(swRegistration.waiting)showUpdate();}catch{toast('Could not check for updates');}}
function registerServiceWorker(){if(IS_NATIVE||!('serviceWorker' in navigator)||!/^https?:$/.test(location.protocol))return;navigator.serviceWorker.register('./sw.js').then(reg=>{swRegistration=reg;if(reg.waiting)showUpdate();reg.addEventListener('updatefound',()=>{const worker=reg.installing;if(!worker)return;worker.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller)showUpdate();});});}).catch(()=>{});navigator.serviceWorker.addEventListener('controllerchange',()=>{if(reloadingForUpdate)return;reloadingForUpdate=true;location.reload();});}

$('#menuBtn').onclick=openDrawer;$('#backdrop').onclick=closeDrawer;$('#brandHome').onclick=()=>setRoute('home');$('#installBtn').onclick=showInstallSheet;$('#drawerInstall').onclick=()=>{closeDrawer();showInstallSheet();};$('#drawerUpdate').onclick=()=>{closeDrawer();checkForUpdate();};$('#sheetBackdrop').onclick=closeSheet;$$('[data-close-sheet]').forEach(b=>b.onclick=closeSheet);$('#dismissUpdate').onclick=hideUpdate;$('#applyUpdate').onclick=()=>{if(swRegistration?.waiting){hideUpdate();swRegistration.waiting.postMessage({type:'SKIP_WAITING'});toast('Updating…');}else{hideUpdate();toast('No web update is waiting');}};
$$('.bottom-nav button').forEach(b=>b.onclick=()=>setRoute(b.dataset.route));window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;$('#installBtn').hidden=false;});window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;toast('Aurai Companion installed');});window.addEventListener('online',updateNetworkLabel);window.addEventListener('offline',updateNetworkLabel);window.addEventListener('popstate',e=>{const u=new URL(location.href);const r=e.state?.route||u.searchParams.get('route')||'home';state.route=allowedRoutes.has(r)?r:'home';render();});window.addEventListener('keydown',e=>{if(e.key==='Escape'){closeDrawer();closeSheet();}});

if(IS_NATIVE){hideUpdate();const updateButton=$('#drawerUpdate');if(updateButton)updateButton.hidden=true;const installButton=$('#installBtn');if(installButton)installButton.setAttribute('aria-label','App info');const drawerInstall=$('#drawerInstall');if(drawerInstall)drawerInstall.textContent='App info';}
if(localStorage.getItem('auraiLegacyDbCleared')!=='1'){deleteLegacyRecipeCache();localStorage.setItem('auraiLegacyDbCleared','1');}
updateNetworkLabel();render();registerServiceWorker();setTimeout(()=>$('#splash')?.classList.add('hide'),520);
