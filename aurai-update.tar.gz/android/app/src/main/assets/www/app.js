const D = window.AURAI_DATA;
const APP_VERSION = '2.4.0';
const WIKI = 'https://outward.wiki.gg';
const WIKI_API = `${WIKI}/api.php`;
const IS_NATIVE = /AuraiAndroid/i.test(navigator.userAgent);
const IS_STANDALONE = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true || IS_NATIVE;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const DB_NAME = 'aurai-companion';
const DB_VERSION = 1;
const DB_STORE = 'cache';
const RECIPE_CACHE_KEY = 'wikiRecipeIndex';
const SYNC_MAX_AGE = 7 * 24 * 60 * 60 * 1000;

function readJSON(key, fallback){try{return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));}catch{return fallback;}}
function canon(v=''){return String(v).normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[’‘]/g,"'").replace(/[^a-z0-9' -]+/g,' ').replace(/\s+/g,' ').trim();}
function esc(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function stripHTML(v=''){const t=document.createElement('textarea');t.innerHTML=String(v).replace(/<[^>]*>/g,' ');return t.value.replace(/\s+/g,' ').trim();}
function haptic(){if(navigator.vibrate) navigator.vibrate(8);}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show');clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>t.classList.remove('show'),1900);}
function wikiURL(page){return `${WIKI}/wiki/${encodeURIComponent(page).replace(/%20/g,'_')}`;}
function openExternal(url){if(IS_NATIVE){location.href=url;}else{window.open(url,'_blank','noopener,noreferrer');}}
function iconFor(type){return type==='Alchemy'?'⚗️':type==='Cooking'?'🍲':type==='Blacksmith'?'⚒️':type==='Crafting'?'🔨':'🛠️';}
function routeTitle(r){return ({home:'Home',recipes:'Crafting & Recipes',pantry:'My Items',shopping:'Shopping List',compare:'Compare',wiki:'Wiki Explorer',guides:'Field Guides',saved:'Saved',settings:'Settings & Data'})[r] || 'Home';}
function countIngredients(items){const map=new Map();for(const item of items)map.set(item,(map.get(item)||0)+1);return [...map.entries()];}
function ingredientCountMap(items){const map={};for(const item of items){const k=canon(item);map[k]=(map[k]||0)+1;}return map;}
function hashString(value){let h=2166136261;for(let i=0;i<value.length;i++){h^=value.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(36);}
function formatDate(ts){if(!ts)return 'Not synced yet';try{return new Intl.DateTimeFormat(undefined,{day:'numeric',month:'short',year:'numeric'}).format(new Date(ts));}catch{return new Date(ts).toLocaleDateString();}}

let catalogRecipes = D.recipes.map(r=>({...r,source:'bundled'}));
let ingredientNames = [];
let ingredientByKey = new Map();
let dbConnection = null;

const allowedRoutes = new Set(['home','recipes','pantry','shopping','compare','wiki','guides','saved','settings']);
const params = new URLSearchParams(location.search);
const initialRoute = allowedRoutes.has(params.get('route')) ? params.get('route') : 'home';
const state = {
  route: initialRoute,
  filter: 'All',
  purpose: 'All',
  query: '',
  pantryQuery: '',
  ingredientQuery: '',
  wikiQuery: '',
  saved: new Set(readJSON('auraiSaved', [])),
  pantry: readJSON('auraiPantry', []),
  plan: new Set(readJSON('auraiPlan', [])),
  loadouts: readJSON('auraiLoadouts', []),
  recentWiki: readJSON('auraiRecentWiki', []),
  compareA: readJSON('auraiCompareA', ''),
  compareB: readJSON('auraiCompareB', ''),
  silver: Math.max(0, Number(readJSON('auraiSilver', 0)) || 0),
  pantryMatch: readJSON('auraiPantryMatch', 'all'),
  dbSource: 'bundled',
  dbUpdatedAt: 0,
  dbSyncing: false,
  dbError: ''
};

let deferredInstallPrompt = null;
let swRegistration = null;
let reloadingForUpdate = false;
let wikiAbort = null;
const app = $('#app');

const PURPOSES = {
  All: [],
  Healing: ['heal','health','bandage','life potion'],
  Mana: ['mana','astral'],
  Stamina: ['stamina','endurance','able tea'],
  Weather: ['warm','cool','cold','hot','weather'],
  Combat: ['damage','imbue','varnish','rage','discipline','ammo','bomb','charge','rag'],
  Travel: ['travel','ration'],
  Food: ['food','drink','tea','stew','jerky','sandwich','cake','tartine'],
  Gear: ['armor','armour','equipment','weapon','blacksmith','commission','boots','helm','helmet']
};

// Known ingredient-family substitutions that are explicitly useful in Outward.
// This is deliberately conservative: exact ingredients are always preferred.
const FULFILLS = {
  'raw meat': ['meat','ration ingredient'],
  'clean water': ['water']
};
const GENERIC_INGREDIENTS = new Set(['meat','ration ingredient','water','bread','egg','fish','mushroom','vegetable','basic armor','basic boots','basic helm']);

function saveState(){
  localStorage.setItem('auraiSaved',JSON.stringify([...state.saved]));
  localStorage.setItem('auraiPantry',JSON.stringify(state.pantry));
  localStorage.setItem('auraiPlan',JSON.stringify([...state.plan]));
  localStorage.setItem('auraiLoadouts',JSON.stringify(state.loadouts));
  localStorage.setItem('auraiRecentWiki',JSON.stringify(state.recentWiki.slice(0,6)));
  localStorage.setItem('auraiCompareA',JSON.stringify(state.compareA||''));
  localStorage.setItem('auraiCompareB',JSON.stringify(state.compareB||''));
  localStorage.setItem('auraiSilver',JSON.stringify(Math.max(0,Number(state.silver)||0)));
  localStorage.setItem('auraiPantryMatch',JSON.stringify(state.pantryMatch||'all'));
}

function rebuildIngredientIndex(){
  ingredientNames=[...new Set(catalogRecipes.flatMap(r=>r.ingredients).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  ingredientByKey=new Map(ingredientNames.map(i=>[canon(i),i]));
}
rebuildIngredientIndex();

function recipeSignature(r){
  const parts=countIngredients(r.ingredients||[]).map(([n,c])=>`${canon(n)}:${c}`).sort();
  return `${canon(r.name)}|${canon(r.station)}|${parts.join('|')}`;
}
function getRecipe(id){return catalogRecipes.find(r=>r.id===id) || D.recipes.find(r=>r.id===id);}
function classifyStation(station='None'){
  const s=canon(station);
  if(s.includes('alchemy'))return 'Alchemy';
  if(s.includes('cooking')||s.includes('campfire')||s.includes('kitchen'))return 'Cooking';
  if(!s||s==='none')return 'Survival';
  return 'Crafting';
}
function cleanCargoValue(value){
  if(value==null)return '';
  return String(value).replace(/\[\[(?:[^|\]]+\|)?([^\]]+)\]\]/g,'$1').replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ').trim();
}
function remoteRecipeFromRow(row){
  const t=row?.title||row||{};
  const page=cleanCargoValue(t._pageName||t.page||t.name);
  const name=cleanCargoValue(t.name)||page;
  const station=cleanCargoValue(t.station)||'None';
  const ingredients=['ingredient1','ingredient2','ingredient3','ingredient4'].map(k=>cleanCargoValue(t[k])).filter(Boolean);
  if(!name||!ingredients.length)return null;
  const count=Math.max(1,parseInt(cleanCargoValue(t.count),10)||1);
  const base={name,type:classifyStation(station),station,yield:count,ingredients,tags:[],note:'',wiki:page||name,source:'wiki-index'};
  return {...base,id:`wiki-${hashString(`${recipeSignature(base)}|${canon(page)}`)}`};
}
function mergeCatalog(remote){
  const curated=D.recipes.map(r=>({...r,source:'bundled'}));
  const seen=new Set(curated.map(recipeSignature));
  const out=[...curated];
  for(const recipe of remote||[]){
    if(!recipe?.ingredients?.length)continue;
    const sig=recipeSignature(recipe);
    if(seen.has(sig))continue;
    seen.add(sig);out.push(recipe);
  }
  out.sort((a,b)=>a.type.localeCompare(b.type)||a.name.localeCompare(b.name)||a.station.localeCompare(b.station));
  return out;
}
function applyRemoteCatalog(remote,updatedAt=Date.now()){
  catalogRecipes=mergeCatalog(remote);
  state.dbSource=remote?.length?'wiki-cache':'bundled';
  state.dbUpdatedAt=updatedAt||0;
  state.dbError='';
  rebuildIngredientIndex();
}

function openDB(){
  if(dbConnection)return Promise.resolve(dbConnection);
  if(!('indexedDB' in window))return Promise.reject(new Error('IndexedDB unavailable'));
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(DB_STORE))db.createObjectStore(DB_STORE,{keyPath:'key'});};
    req.onsuccess=()=>{dbConnection=req.result;resolve(dbConnection);};
    req.onerror=()=>reject(req.error||new Error('Could not open offline database'));
  });
}
async function dbGet(key){
  const db=await openDB();
  return new Promise((resolve,reject)=>{const tx=db.transaction(DB_STORE,'readonly');const req=tx.objectStore(DB_STORE).get(key);req.onsuccess=()=>resolve(req.result?.value||null);req.onerror=()=>reject(req.error);});
}
async function dbPut(key,value){
  const db=await openDB();
  return new Promise((resolve,reject)=>{const tx=db.transaction(DB_STORE,'readwrite');tx.objectStore(DB_STORE).put({key,value});tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});
}
async function loadCachedRecipeDatabase(){
  try{
    const cached=await dbGet(RECIPE_CACHE_KEY);
    if(cached?.recipes?.length){
      applyRemoteCatalog(cached.recipes,cached.updatedAt);
      render();
      return cached;
    }
  }catch{}
  return null;
}
async function fetchWikiRecipeIndex(){
  let all=[];let offset=0;const limit=500;
  for(let page=0;page<5;page++){
    const q=new URLSearchParams({
      action:'cargoquery',format:'json',origin:'*',tables:'ItemRecipes',
      fields:'_pageName,name,count,ingredient1,ingredient2,ingredient3,ingredient4,station',
      limit:String(limit),offset:String(offset)
    });
    const res=await fetch(`${WIKI_API}?${q.toString()}`,{headers:{Accept:'application/json'}});
    if(!res.ok)throw new Error(`Wiki recipe index returned HTTP ${res.status}`);
    const data=await res.json();
    if(data?.error)throw new Error(data.error.info||'Wiki recipe index unavailable');
    const batch=(data?.cargoquery||[]).map(remoteRecipeFromRow).filter(Boolean);
    all.push(...batch);
    if((data?.cargoquery||[]).length<limit)break;
    offset+=limit;
  }
  const unique=[];const seen=new Set();
  for(const r of all){const sig=recipeSignature(r);if(!seen.has(sig)){seen.add(sig);unique.push(r);}}
  if(unique.length<50)throw new Error('Wiki returned an incomplete recipe index');
  return unique;
}
async function syncRecipeDatabase({silent=false}={}){
  if(state.dbSyncing)return;
  if(!navigator.onLine){if(!silent)toast('Go online to refresh the recipe database');return;}
  state.dbSyncing=true;state.dbError='';if(!silent)render();
  try{
    const recipes=await fetchWikiRecipeIndex();
    const updatedAt=Date.now();
    await dbPut(RECIPE_CACHE_KEY,{recipes,updatedAt});
    applyRemoteCatalog(recipes,updatedAt);
    if(!silent)toast(`Recipe database ready · ${catalogRecipes.length} recipes`);
  }catch(err){
    state.dbError='sync-unavailable';
    if(!silent)toast('Could not refresh recipe database');
  }finally{state.dbSyncing=false;updateNetworkLabel();render();}
}
async function initRecipeDatabase(){
  const cached=await loadCachedRecipeDatabase();
  const stale=!cached?.updatedAt || Date.now()-cached.updatedAt>SYNC_MAX_AGE;
  if(navigator.onLine && stale)syncRecipeDatabase({silent:true});
}

function levenshtein(a,b){
  a=canon(a);b=canon(b);if(a===b)return 0;if(!a.length)return b.length;if(!b.length)return a.length;
  const prev=Array.from({length:b.length+1},(_,i)=>i);const cur=new Array(b.length+1);
  for(let i=1;i<=a.length;i++){
    cur[0]=i;
    for(let j=1;j<=b.length;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));
    for(let j=0;j<=b.length;j++)prev[j]=cur[j];
  }
  return prev[b.length];
}

const SEARCH_ALIASES = {
  armour:'armor', armours:'armor', armored:'armor',
  helmet:'helm', helmets:'helm',
  ammunition:'ammo', munition:'ammo',
  crafting:'craft', crafted:'craft', crafts:'craft', recipe:'craft', recipes:'craft',
  smith:'blacksmith', blacksmithing:'blacksmith',
  healing:'heal', health:'heal',
  endurance:'stamina'
};
function searchToken(v){const c=canon(v);return SEARCH_ALIASES[c]||c;}
function searchTerms(raw){return canon(raw).split(/[\s,;+]+/).filter(Boolean).map(searchToken);}
function recipeSearchFields(r){
  const method = r.type==='Blacksmith' ? 'blacksmith commission commissioned craft crafting armor equipment' : 'craft crafting recipe';
  return {
    name: canon(r.name).split(/\s+/).map(searchToken),
    nameText: canon(r.name).split(/\s+/).map(searchToken).join(' '),
    tags: (r.tags||[]).flatMap(x=>canon(x).split(/\s+/)).map(searchToken),
    ingredients: (r.ingredients||[]).flatMap(x=>canon(x).split(/\s+/)).map(searchToken),
    station: canon(r.station||'').split(/\s+/).map(searchToken),
    note: canon(r.note||'').split(/\s+/).map(searchToken),
    method: method.split(/\s+/).map(searchToken)
  };
}
function termScore(term,fields){
  if(fields.name.includes(term))return 120;
  if(fields.tags.includes(term))return 105;
  if(fields.ingredients.includes(term))return 92;
  if(fields.station.includes(term))return 80;
  if(fields.method.includes(term))return 72;
  if(fields.note.includes(term))return 55;
  if(term.length>=5){
    if(fields.name.some(w=>w.startsWith(term)))return 65;
    if(fields.tags.some(w=>w.startsWith(term)))return 58;
    if(fields.ingredients.some(w=>w.startsWith(term)))return 52;
  }
  if(term.length>=5){
    const max=term.length<=7?1:2;
    for(const [words,score] of [[fields.name,42],[fields.tags,36],[fields.ingredients,32]]){
      if(words.some(w=>Math.abs(w.length-term.length)<=max&&levenshtein(term,w)<=max))return score;
    }
  }
  return -1;
}
function recipeSearchScore(r,raw){
  const terms=searchTerms(raw);if(!terms.length)return 0;
  const fields=recipeSearchFields(r);let score=0;
  for(const term of terms){const s=termScore(term,fields);if(s<0)return -1;score+=s;}
  const q=terms.join(' ');
  if(fields.nameText===q)score+=500;
  else if(fields.nameText.startsWith(q))score+=260;
  else if(fields.nameText.includes(q))score+=170;
  if(r.type==='Blacksmith'&&terms.some(t=>['armor','blacksmith','craft'].includes(t)))score+=35;
  return score;
}
function fuzzyTermMatch(term,haystack){
  term=searchToken(term);const words=canon(haystack).split(/\s+/).map(searchToken).filter(Boolean);
  if(words.includes(term))return true;
  if(term.length<5)return false;
  const max=term.length<=7?1:2;
  return words.some(w=>Math.abs(w.length-term.length)<=max&&levenshtein(term,w)<=max);
}
function recipeHaystack(r){return [r.name,r.type,r.station,...(r.ingredients||[]),...(r.tags||[]),r.note||'',r.type==='Blacksmith'?'blacksmith commission crafting':'craft recipe'].join(' ');}
function matchesTerms(r,raw){return recipeSearchScore(r,raw)>=0;}
function matchesPurpose(r,purpose){if(!purpose||purpose==='All')return true;const keys=PURPOSES[purpose]||[];const hay=canon(recipeHaystack(r));return keys.some(k=>hay.includes(canon(k)));}
function ingredientSearchMatches(raw,limit=8){
  const q=canon(raw);if(!q)return [];
  const scored=ingredientNames.map(name=>{
    const c=canon(name);let score=99;
    if(c===q)score=0;else if(c.startsWith(q))score=1;else if(c.includes(q))score=2;else{const d=levenshtein(q,c);const word=Math.min(...c.split(' ').map(w=>levenshtein(q,w)));score=3+Math.min(d,word);}
    return {name,score};
  }).filter(x=>x.score<=Math.max(5,Math.floor(q.length/2)+2)).sort((a,b)=>a.score-b.score||a.name.localeCompare(b.name));
  return scored.slice(0,limit);
}
function normalizeIngredient(value){
  const v=String(value||'').trim();if(!v)return '';
  const exact=ingredientByKey.get(canon(v));if(exact)return exact;
  const best=ingredientSearchMatches(v,1)[0];
  if(best && best.score<=5)return best.name;
  return v;
}
function fulfillsItem(owned,needed){
  const o=canon(owned),n=canon(needed);if(o===n)return true;
  return (FULFILLS[o]||[]).includes(n);
}
function pantryStatus(r,items=state.pantry){
  const available=items.map((name,i)=>({name,key:canon(name),i,used:false}));
  const needs=(r.ingredients||[]).map(name=>({name,key:canon(name),generic:GENERIC_INGREDIENTS.has(canon(name))})).sort((a,b)=>Number(a.generic)-Number(b.generic));
  let haveUnits=0;const missingNames=[];
  for(const need of needs){
    let idx=available.findIndex(x=>!x.used&&x.key===need.key);
    if(idx<0)idx=available.findIndex(x=>!x.used&&fulfillsItem(x.name,need.name));
    if(idx>=0){available[idx].used=true;haveUnits++;}else missingNames.push(need.name);
  }
  const missing=countIngredients(missingNames);const totalUnits=needs.length;const missingUnits=missingNames.length;
  const silverNeeded=Math.max(0,Number(r.silverCost)||0);
  const silverReady=!silverNeeded||Number(state.silver||0)>=silverNeeded;
  const materialsReady=missingUnits===0;
  return {craftable:materialsReady&&silverReady,materialsReady,silverReady,silverNeeded,haveUnits,totalUnits,missingUnits,missing,ratio:totalUnits?haveUnits/totalUnits:0};
}

function recipeCard(r,status=null){
  const ready=status?.craftable;const materialReady=status?.materialsReady&&!ready;const partial=status&&!status.materialsReady&&status.haveUnits>0;
  const progress=ready?`<span class="chip green">${r.type==='Blacksmith'?'Ready to commission':'Craftable now'}</span>`:
    materialReady?`<span class="chip amber">Materials ready · ${status.silverNeeded} silver</span>`:
    partial?`<span class="chip amber">Have ${status.haveUnits}/${status.totalUnits}</span>`:'';
  const planned=state.plan.has(r.id)?'<span class="chip blue">Planned</span>':'';
  const missing=partial?`<div class="missing-line">Missing: ${status.missing.map(([n,c])=>`${esc(n)}${c>1?` ×${c}`:''}`).join(' · ')}</div>`:'';
  const cost=r.silverCost?`<div class="cost-line">${esc(r.silverCost)} silver${r.type==='Blacksmith'?' · commissioned':''}</div>`:'';
  return `<article class="recipe-card ${ready?'match':partial||materialReady?'near-match':''}" data-recipe="${esc(r.id)}">
    <div class="recipe-icon">${iconFor(r.type)}</div><div class="card-main"><div class="card-title">${esc(r.name)} ×${esc(r.yield)}</div>
    <div class="meta"><span class="chip gold">${esc(r.type)}</span><span class="chip">${esc(r.station)}</span>${progress}${planned}</div>
    <div class="ingredients">${(r.ingredients||[]).map(esc).join(' · ')}</div>${cost}${missing}</div>
    <button class="save-btn ${state.saved.has(r.id)?'saved':''}" data-save="${esc(r.id)}" aria-label="${state.saved.has(r.id)?'Remove saved recipe':'Save recipe'}">${state.saved.has(r.id)?'♥':'♡'}</button>
  </article>`;
}
function getRecipeList(){
  let list=catalogRecipes.filter(r=>state.filter==='All'||r.type===state.filter);
  if(state.purpose!=='All')list=list.filter(r=>matchesPurpose(r,state.purpose));
  if(state.query.trim()){
    list=list.map(r=>({r,score:recipeSearchScore(r,state.query)})).filter(x=>x.score>=0).sort((a,b)=>b.score-a.score||a.r.name.localeCompare(b.r.name)).map(x=>x.r);
  }else{
    list=list.slice().sort((a,b)=>a.name.localeCompare(b.name)||a.station.localeCompare(b.station));
  }
  return list;
}
function databaseStatusHTML(){
  const full=state.dbSource==='wiki-cache';const count=catalogRecipes.length;
  const message=full?`${count} cached recipes · refreshed ${formatDate(state.dbUpdatedAt)}`:`${count} built-in recipes & commissions`;
  const error=state.dbError?'<small>Full wiki sync is unavailable right now. The built-in offline catalogue still works.</small>':'';
  return `<div class="database-card ${full?'ready':''}"><div><strong>${full?'Offline database ready':'Offline catalogue ready'}</strong><span>${message}</span>${error}</div><button id="syncRecipes" ${state.dbSyncing?'disabled':''}>${state.dbSyncing?'Syncing…':full?'Refresh':'Sync full database'}</button></div>`;
}

function home(){
  const featured=['bandages','campfire','bread','great-astral-b'].map(getRecipe).filter(Boolean);
  return `<section class="hero"><div class="hero-kicker">Outward companion</div><h1>Find the answer without leaving the adventure.</h1>
    <p>Crafting, blacksmith commissions, alchemy, ingredient matching, shopping lists, practical guides and Outward Wiki lookup in one phone-friendly companion.</p>
    <div class="hero-stats"><span class="hero-stat">Offline crafting catalogue</span><span class="hero-stat">Ingredient matcher</span><span class="hero-stat">Saved on device</span></div>
    <div class="searchbox"><input id="homeSearch" placeholder="Search recipe or ingredients…" autocomplete="off"><button id="homeGo">Search</button></div></section>
  <div class="section-head"><div><h2>Quick access</h2><p>Useful while you are actually playing</p></div></div>
  <div class="quick-grid">
    <button class="quick-card" data-go="recipes" data-filter="Alchemy"><span class="emoji">⚗️</span><span class="arrow">›</span><strong>Alchemy</strong><small>Potions, charges and alchemy recipes</small></button>
    <button class="quick-card" data-go="recipes" data-filter="Cooking"><span class="emoji">🍲</span><span class="arrow">›</span><strong>Cooking</strong><small>Campfire and Cooking Pot recipes</small></button>
    <button class="quick-card" data-go="pantry"><span class="emoji">🎒</span><span class="arrow">›</span><strong>What can I make?</strong><small>Rank recipes from the ingredients you have</small></button>
    <button class="quick-card" data-go="shopping"><span class="emoji">🧾</span><span class="arrow">›</span><strong>Shopping list</strong><small>Combine missing ingredients for planned recipes</small></button>
    <button class="quick-card" data-go="recipes" data-filter="Blacksmith"><span class="emoji">⚒️</span><span class="arrow">›</span><strong>Blacksmith</strong><small>Commissioned armour and equipment</small></button>
    <button class="quick-card" data-go="compare"><span class="emoji">⚖️</span><span class="arrow">›</span><strong>Compare</strong><small>Compare two crafts side by side</small></button>
    <button class="quick-card" data-go="wiki"><span class="emoji">📖</span><span class="arrow">›</span><strong>Wiki Explorer</strong><small>Items, enemies, quests and detailed pages</small></button>
  </div>
  <div class="section-head"><div><h2>Useful recipes</h2><p>Common crafts kept instantly available</p></div><button data-go="recipes" data-filter="All">View all</button></div>
  <div class="cards grid">${featured.map(r=>recipeCard(r)).join('')}</div>
  <div class="section-head"><div><h2>Need a tip?</h2><p>Short practical guidance without wiki digging</p></div><button data-go="guides">All guides</button></div>
  <div class="cards">${D.guides.slice(0,2).map(guideCard).join('')}</div>`;
}
function recipeResultsHTML(){
  const list=getRecipeList();const q=state.query.trim();
  const heading=`<div class="results-head"><strong>${list.length}</strong><span>${q?`result${list.length===1?'':'s'} for “${esc(q)}”`:'crafts in the current filters'}</span>${q?`<button data-wiki-search="${esc(q)}">Search Wiki</button>`:''}</div>`;
  if(list.length)return `${heading}<div class="cards" id="recipeList">${list.map(r=>recipeCard(r)).join('')}</div>`;
  return `${heading}<div class="empty search-empty"><b>No offline crafting match</b><span>Try fewer words, clear a filter, or search the full Outward Wiki.</span><div class="empty-actions"><button class="secondary-btn" id="clearRecipeFilters">Clear filters</button>${q?`<button class="primary-btn" data-wiki-search="${esc(q)}">Search Wiki</button>`:''}</div></div>`;
}
function recipes(){
  const activeFilters=(state.filter!=='All'?1:0)+(state.purpose!=='All'?1:0);
  return `<div class="page-title compact-title"><h1>Crafting & Recipes</h1><p>Search manual recipes, ingredients and blacksmith commissions. Typos and UK/US armour spelling are handled.</p></div>
  <div class="recipe-search-panel">
    <div class="search-input-wrap"><input id="recipeSearch" value="${esc(state.query)}" placeholder="Blue Sand armour, ammo, Livweedi…" autocomplete="off" enterkeyhint="search"><button id="clearRecipeSearch" class="input-clear" ${state.query?'':'hidden'} aria-label="Clear search">×</button></div>
    <details class="filter-panel" ${activeFilters?'open':''}><summary>Filters${activeFilters?` <span>${activeFilters}</span>`:''}</summary>
      <div class="filter-label">Craft type</div><div class="filter-row">${['All','Survival','Cooking','Alchemy','Blacksmith','Crafting'].map(x=>`<button data-filter="${x}" class="${state.filter===x?'active':''}">${x}</button>`).join('')}</div>
      <div class="filter-label">Purpose</div><div class="filter-row purpose-row">${Object.keys(PURPOSES).map(x=>`<button data-purpose="${x}" class="${state.purpose===x?'active':''}">${x}</button>`).join('')}</div>
    </details>
    <div class="catalog-mini"><span>${catalogRecipes.length} offline entries${state.dbSource==='wiki-cache'?' · full recipe cache synced':' · built-in catalogue'}</span><button data-go="settings">Database & backup</button></div>
  </div>
  ${state.query.trim()?'':`<div class="notice slim-notice"><strong>Have ingredients already?</strong> My Items ranks what you can make now and what is only one or two ingredients away. <button class="link-btn" data-go="pantry">Open My Items</button></div>`}
  <div id="recipeResults">${recipeResultsHTML()}</div>`;
}
function recipeListHTML(){const list=getRecipeList();return list.length?list.map(r=>recipeCard(r)).join(''):'<div class="empty">No match.</div>';}
function ingredientSuggestionHTML(raw){const list=ingredientSearchMatches(raw);return list.length?list.map(x=>`<button data-ingredient-suggestion="${esc(x.name)}"><strong>${esc(x.name)}</strong><small>tap to add</small></button>`).join(''):raw.trim()?'<span>No close ingredient names found — you can still add exactly what you typed.</span>':'';}

function loadoutsInlineHTML(){
  if(!state.loadouts.length)return '';
  return `<div class="loadout-strip">${state.loadouts.slice(0,5).map(l=>`<button data-load-loadout="${esc(l.id)}">${esc(l.name)} <small>${l.items.length}</small></button>`).join('')}</div>`;
}
function pantry(){
  const grouped={};state.pantry.forEach(item=>{const k=canon(item);if(!grouped[k])grouped[k]={key:k,name:ingredientByKey.get(k)||item,count:0};grouped[k].count++;});
  const statuses=catalogRecipes.map(r=>({r,s:pantryStatus(r)}));
  const filterByPantryQuery=x=>!state.pantryQuery.trim()||matchesTerms(x.r,state.pantryQuery);
  let craftable=statuses.filter(x=>x.s.craftable&&filterByPantryQuery(x)).sort((a,b)=>a.r.name.localeCompare(b.r.name));
  let close=statuses.filter(x=>!x.s.craftable&&x.s.haveUnits>0&&filterByPantryQuery(x)).sort((a,b)=>a.s.missingUnits-b.s.missingUnits||b.s.ratio-a.s.ratio||a.r.name.localeCompare(b.r.name));
  if(state.pantryMatch==='one')close=close.filter(x=>x.s.missingUnits<=1);
  if(state.pantryMatch==='two')close=close.filter(x=>x.s.missingUnits<=2);
  if(state.pantryMatch==='ready')close=[];
  const common=['Water','Clean Water','Linen Cloth','Wood','Salt','Raw Meat','Thick Oil','Blue Sand'].filter(x=>ingredientByKey.has(canon(x)));
  return `<div class="page-title"><h1>My Items</h1><p>Add what you actually have. Aurai ranks crafts and commissions by how close you are.</p></div>
  <div class="pantry-action-row"><button id="saveLoadout" ${!state.pantry.length?'disabled':''}>Save loadout</button><button id="manageLoadouts">Loadouts ${state.loadouts.length?`(${state.loadouts.length})`:''}</button><button data-go="shopping">Shopping ${state.plan.size?`(${state.plan.size})`:''}</button></div>
  ${loadoutsInlineHTML()}
  <div class="pantry-add smart-add"><textarea id="pantryInput" rows="2" placeholder="Add items — e.g. 5x Blue Sand, Linen Cloth x2" autocomplete="off"></textarea><button class="primary-btn" id="pantryAdd">Add</button></div>
  <div class="ingredient-suggestions" id="ingredientSuggestions"></div>
  ${!state.pantry.length&&common.length?`<div class="quick-ingredients"><span>Quick add</span>${common.map(i=>`<button data-quick-ingredient="${esc(i)}">+ ${esc(i)}</button>`).join('')}</div>`:''}
  <div class="silver-row"><label for="silverInput"><span>Silver on hand</span><small>Used for blacksmith commission readiness</small></label><div><input id="silverInput" type="number" min="0" inputmode="numeric" value="${esc(state.silver)}"><span>silver</span></div></div>
  <div class="pantry-list">${state.pantry.length?Object.values(grouped).map(g=>`<span class="pantry-pill"><button class="qty-btn" data-pantry-dec="${encodeURIComponent(g.key)}" aria-label="Remove one ${esc(g.name)}">−</button><button class="ingredient-name-btn" data-ingredient-open="${esc(g.name)}">${esc(g.name)}${g.count>1?` ×${g.count}`:''}</button><button class="qty-btn plus" data-pantry-inc="${encodeURIComponent(g.key)}" aria-label="Add another ${esc(g.name)}">+</button></span>`).join(''):'<span class="chip">No items added yet</span>'}</div>
  ${state.pantry.length?`<div class="pantry-tools"><input id="pantryRecipeSearch" value="${esc(state.pantryQuery)}" placeholder="Filter matching crafts…"><button id="clearPantry">Clear items</button></div>
  <div class="match-filter"><span>Show near matches</span>${[['all','Any'],['one','1 missing'],['two','≤2 missing'],['ready','Ready only']].map(([v,n])=>`<button data-pantry-match="${v}" class="${state.pantryMatch===v?'active':''}">${n}</button>`).join('')}</div>`:''}
  ${state.pantry.length?`<div class="result-summary"><strong>${craftable.length}</strong> ready now <span>·</span> <strong>${close.length}</strong> partial matches</div>`:'<div class="notice"><strong>Tip:</strong> paste several items at once. Enter silver separately above for blacksmith commissions.</div>'}
  ${state.pantry.length?`<div class="section-head"><div><h2>Ready now</h2><p>All tracked requirements are covered</p></div></div><div class="cards">${craftable.length?craftable.slice(0,80).map(x=>recipeCard(x.r,x.s)).join(''):'<div class="empty">Nothing complete yet. The closest options are below.</div>'}</div>
  ${state.pantryMatch!=='ready'?`<div class="section-head"><div><h2>Closest matches</h2><p>Fewest missing materials first</p></div></div><div class="cards">${close.length?close.slice(0,80).map(x=>recipeCard(x.r,x.s)).join(''):'<div class="empty">No partial matches for the current filter.</div>'}</div>`:''}`:''}`;
}

function shoppingSummary(){
  const recipes=[...state.plan].map(getRecipe).filter(Boolean);const needed=[];recipes.forEach(r=>needed.push(...r.ingredients));
  const inventory=[...state.pantry];const available=inventory.map(name=>({name,key:canon(name),used:false}));const missing=[];
  const needs=needed.map(name=>({name,key:canon(name),generic:GENERIC_INGREDIENTS.has(canon(name))})).sort((a,b)=>Number(a.generic)-Number(b.generic));
  for(const need of needs){let idx=available.findIndex(x=>!x.used&&x.key===need.key);if(idx<0)idx=available.findIndex(x=>!x.used&&fulfillsItem(x.name,need.name));if(idx>=0)available[idx].used=true;else missing.push(need.name);}
  const silverTotal=recipes.reduce((n,r)=>n+(Number(r.silverCost)||0),0);
  return {recipes,missing:countIngredients(missing),needed:countIngredients(needed),silverTotal,silverShortfall:Math.max(0,silverTotal-(Number(state.silver)||0))};
}
function shopping(){
  const s=shoppingSummary();
  return `<div class="page-title"><h1>Shopping List</h1><p>Plan recipes and Aurai combines what you still need after checking My Items.</p></div>
  ${!s.recipes.length?'<div class="empty large-empty"><b>No recipes planned yet</b><span>Open any recipe and tap “Add to shopping list”.</span><button data-go="recipes" class="primary-btn">Browse recipes</button></div>':`<div class="shopping-summary"><div><strong>${s.recipes.length}</strong><span>planned crafts</span></div><div><strong>${s.missing.reduce((n,[,c])=>n+c,0)}</strong><span>materials missing</span></div>${s.silverTotal?`<div><strong>${s.silverTotal}</strong><span>silver total${s.silverShortfall?` · ${s.silverShortfall} short`:``}</span></div>`:``}</div>
  <div class="section-head"><div><h2>Still needed</h2><p>Combined across every planned recipe</p></div><button id="copyShopping">Copy list</button></div>
  <div class="shopping-list">${s.missing.length?s.missing.map(([name,count])=>`<button data-ingredient-open="${esc(name)}"><span>${esc(name)}</span><strong>×${count}</strong></button>`).join(''):'<div class="notice success-note"><strong>You already have everything in My Items.</strong></div>'}</div>
  <div class="section-head"><div><h2>Planned recipes</h2><p>Tap a recipe for details</p></div><button id="clearPlan">Clear all</button></div><div class="cards">${s.recipes.map(r=>recipeCard(r,pantryStatus(r))).join('')}</div>`}`;
}

function compareRecipePanel(r){
  if(!r)return '<div class="compare-empty">Choose a recipe above.</div>';
  const status=state.pantry.length?pantryStatus(r):null;
  const requirementLabel=r.type==='Blacksmith'?'Materials':'Ingredients';
  const readiness=status?(status.craftable?(r.type==='Blacksmith'?'Ready to commission':'Ready to make'):status.materialsReady&&r.silverCost?`Materials ready · ${Math.max(0,status.silverNeeded-(Number(state.silver)||0))} silver short`:`Have ${status.haveUnits}/${status.totalUnits}`):'';
  return `<div class="compare-panel"><div class="recipe-icon">${iconFor(r.type)}</div><h3>${esc(r.name)}</h3><div class="meta"><span class="chip gold">${esc(r.type)}</span><span class="chip">${esc(r.station)}</span></div>
    <dl><dt>Makes</dt><dd>${esc(r.yield)}</dd><dt>${requirementLabel}</dt><dd>${countIngredients(r.ingredients).map(([n,c])=>`${esc(n)}${c>1?` ×${c}`:''}`).join('<br>')}${r.silverCost?`<br>${esc(r.silverCost)} silver`:''}</dd><dt>Use / tags</dt><dd>${(r.tags||[]).length?(r.tags||[]).map(esc).join(' · '):esc(r.note||'No quick-use tags in the recipe index')}</dd>${status?`<dt>My Items</dt><dd>${readiness}</dd>`:''}</dl>
    <button data-recipe="${esc(r.id)}" class="secondary-btn compare-open">Open ${r.type==='Blacksmith'?'commission':'recipe'}</button></div>`;
}
function compare(){
  const a=getRecipe(state.compareA),b=getRecipe(state.compareB);
  const picker=(slot,r)=>`<button class="compare-picker" data-compare-pick="${slot}"><span>${r?`${iconFor(r.type)} ${esc(r.name)}`:'Choose craft…'}</span><small>${r?esc(r.station):'Tap to search'}</small></button>`;
  return `<div class="page-title"><h1>Compare</h1><p>Choose two crafts without scrolling through a huge system dropdown.</p></div>
  <div class="compare-selects"><label>Craft A${picker('A',a)}</label><label>Craft B${picker('B',b)}</label></div>
  <div class="compare-actions">${(a||b)?'<button id="clearCompare" class="secondary-btn">Clear comparison</button>':''}</div>
  <div class="compare-grid">${compareRecipePanel(a)}${compareRecipePanel(b)}</div>`;
}
function recipePickerResultsHTML(query=''){
  let list=catalogRecipes;
  if(query.trim())list=list.map(r=>({r,score:recipeSearchScore(r,query)})).filter(x=>x.score>=0).sort((a,b)=>b.score-a.score||a.r.name.localeCompare(b.r.name)).map(x=>x.r);
  else list=list.slice().sort((a,b)=>a.name.localeCompare(b.name));
  return list.slice(0,60).map(r=>`<button class="picker-row" data-picker-recipe="${esc(r.id)}"><span>${iconFor(r.type)} <strong>${esc(r.name)}</strong><small>${esc(r.type)} · ${esc(r.station)}</small></span><b>›</b></button>`).join('')||'<div class="empty">No matching craft.</div>';
}
function openRecipePicker(slot){
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">Compare</div><h2>Choose craft ${slot}</h2></div></div><div class="picker-search"><input id="pickerSearch" placeholder="Search recipe, ingredient or armour…" autocomplete="off" enterkeyhint="search"></div><div id="pickerResults" class="picker-results">${recipePickerResultsHTML('')}</div>`);
  const bind=()=>$$('[data-picker-recipe]').forEach(b=>b.onclick=()=>{if(slot==='A')state.compareA=b.dataset.pickerRecipe;else state.compareB=b.dataset.pickerRecipe;saveState();closeSheet();render();});
  bind();
  const input=$('#pickerSearch');input.oninput=e=>{const box=$('#pickerResults');box.innerHTML=recipePickerResultsHTML(e.target.value);bind();};requestAnimationFrame(()=>input.focus());
}

function guideCard(g){return `<article class="guide-card"><h3>${g.icon} ${esc(g.title)}</h3><p>${esc(g.text)}</p>${g.points?.length?`<ul>${g.points.map(p=>`<li>${esc(p)}</li>`).join('')}</ul>`:''}</article>`;}
function guides(){return `<div class="page-title"><h1>Field Guides</h1><p>Short practical notes for decisions that come up often during a run.</p></div><div class="cards">${D.guides.map(guideCard).join('')}</div><div class="notice" style="margin-top:14px">For exact mechanics and unusual cases, use Wiki Explorer to open the current Outward Wiki article.</div>`;}
function saved(){const list=catalogRecipes.filter(r=>state.saved.has(r.id));return `<div class="page-title"><h1>Saved</h1><p>Favourite recipes are stored on this device.</p></div><div class="cards">${list.length?list.map(r=>recipeCard(r)).join(''):'<div class="empty">Tap ♡ on a recipe to keep it here.</div>'}</div>`;}


function settings(){
  return `<div class="page-title"><h1>Settings & Data</h1><p>Manage the offline database, backups and local app data.</p></div>
  <div class="settings-stack">
    <section class="settings-card"><div class="settings-card-head"><div><span class="settings-icon">🗃️</span><h2>Offline crafting database</h2></div><span class="chip ${state.dbSource==='wiki-cache'?'green':'gold'}">${catalogRecipes.length} entries</span></div>
      <p>Built-in recipes and blacksmith commissions always work offline. When the wiki recipe index is available, Sync adds the wider manual recipe catalogue to this phone.</p>
      ${databaseStatusHTML()}
    </section>
    <section class="settings-card"><div class="settings-card-head"><div><span class="settings-icon">💾</span><h2>Backup & restore</h2></div></div>
      <p>Back up favourites, My Items, silver, shopping plans, loadouts and recent lookups.</p>
      <div class="settings-actions"><button id="exportBackup" class="primary-btn">Export backup</button><label class="secondary-btn file-label">Import backup<input id="importBackup" type="file" accept="application/json,.json" hidden></label></div>
      <div class="settings-actions"><button id="copyBackup" class="secondary-btn">Copy backup text</button><button id="pasteBackup" class="secondary-btn">Paste backup text</button></div>
    </section>
    <section class="settings-card danger-card"><div class="settings-card-head"><div><span class="settings-icon">↺</span><h2>Reset local data</h2></div></div>
      <p>This clears favourites, inventory, loadouts, shopping plans and the locally synced wiki recipe cache.</p>
      <button id="resetLocalData" class="danger-btn">Reset app data</button>
    </section>
    <section class="settings-card"><div class="settings-card-head"><div><span class="settings-icon">ℹ️</span><h2>About</h2></div><span class="chip">v${APP_VERSION}</span></div>
      <p>Aurai Companion is a fan-made Outward helper. Detailed wiki links open outward.wiki.gg. APK updates are built through your signed GitHub workflow.</p>
    </section>
  </div>`;
}
function backupPayload(){
  return {format:'aurai-companion-backup',schema:1,appVersion:APP_VERSION,createdAt:new Date().toISOString(),data:{
    saved:[...state.saved],pantry:[...state.pantry],silver:Number(state.silver)||0,plan:[...state.plan],
    loadouts:state.loadouts,recentWiki:state.recentWiki,compareA:state.compareA||'',compareB:state.compareB||'',pantryMatch:state.pantryMatch||'all'
  }};
}
function backupJSON(){return JSON.stringify(backupPayload(),null,2);}
function legacyCopyText(text){
  const ta=document.createElement('textarea');ta.value=text;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();
  let ok=false;try{ok=document.execCommand('copy');}catch{}ta.remove();return ok;
}
async function copyTextSafe(text){
  try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return true;}}catch{}
  return legacyCopyText(text);
}
async function exportBackup(){
  const text=backupJSON();
  if(IS_NATIVE){
    showSheet(`<div class="detail-head"><div><div class="hero-kicker">Backup</div><h2>App data backup</h2></div></div><p class="sheet-copy">Copy this backup to Notes, Drive or another safe place. It contains your local Aurai data, not game save files.</p><textarea class="backup-text" id="backupText" readonly>${esc(text)}</textarea><div class="actions"><button class="primary-btn" id="copyBackupSheet">Copy backup</button></div>`);
    $('#copyBackupSheet').onclick=async()=>toast(await copyTextSafe(text)?'Backup copied':'Could not copy backup');
    return;
  }
  const blob=new Blob([text],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');
  a.href=url;a.download=`aurai-companion-backup-${new Date().toISOString().slice(0,10)}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast('Backup exported');
}
async function copyBackup(){toast(await copyTextSafe(backupJSON())?'Backup copied':'Could not copy backup');}
function restoreBackupObject(parsed){
  if(parsed?.format!=='aurai-companion-backup'||!parsed?.data)throw new Error('Not an Aurai backup');
  const d=parsed.data;
  state.saved=new Set(Array.isArray(d.saved)?d.saved:[]);
  state.pantry=Array.isArray(d.pantry)?d.pantry:[];
  state.silver=Math.max(0,Number(d.silver)||0);
  state.plan=new Set(Array.isArray(d.plan)?d.plan:[]);
  state.loadouts=Array.isArray(d.loadouts)?d.loadouts:[];
  state.recentWiki=Array.isArray(d.recentWiki)?d.recentWiki:[];
  state.compareA=d.compareA||'';state.compareB=d.compareB||'';
  state.pantryMatch=['all','one','two','ready'].includes(d.pantryMatch)?d.pantryMatch:'all';
  saveState();render();toast('Backup restored');
}
async function importBackupFile(file){
  if(!file)return;
  try{restoreBackupObject(JSON.parse(await file.text()));}catch{toast('That backup could not be imported');}
}
function pasteBackupSheet(){
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">Restore</div><h2>Paste backup text</h2></div></div><p class="sheet-copy">Paste an Aurai Companion backup below.</p><textarea class="backup-text editable" id="pastedBackup" placeholder="Paste backup JSON here…"></textarea><button class="primary-btn full-btn" id="restorePastedBackup">Restore backup</button>`);
  $('#restorePastedBackup').onclick=()=>{try{restoreBackupObject(JSON.parse($('#pastedBackup').value));closeSheet();render();toast('Backup restored');}catch{toast('That backup text is not valid');}};
  requestAnimationFrame(()=>$('#pastedBackup')?.focus());
}
function resetDataSheet(){
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">Settings</div><h2>Reset local data?</h2></div></div><p class="sheet-copy">This clears your saved recipes, My Items, loadouts, shopping list, comparison choices and offline wiki recipe cache. The built-in catalogue remains.</p><div class="actions"><button class="secondary-btn" data-close-sheet>Cancel</button><button class="danger-btn" id="confirmReset">Reset</button></div>`);
  $$('[data-close-sheet]').forEach(b=>b.onclick=closeSheet);
  $('#confirmReset').onclick=async()=>{['auraiSaved','auraiPantry','auraiPlan','auraiLoadouts','auraiRecentWiki','auraiCompareA','auraiCompareB','auraiSilver','auraiPantryMatch'].forEach(k=>localStorage.removeItem(k));try{await dbPut(RECIPE_CACHE_KEY,{recipes:[],updatedAt:0});}catch{}location.reload();};
}

const wikiAreas=[['⚗️','Alchemy','Alchemy'],['🍲','Cooking','Cooking'],['⚔️','Weapons','Weapons'],['🛡️','Equipment','Equipment'],['👹','Enemies','Enemies'],['🗺️','Locations','Locations'],['📜','Quests','Quests'],['✨','Skills','Skills'],['🔮','Enchantments','Enchantments']];
function wiki(){
  return `<div class="page-title"><h1>Wiki Explorer</h1><p>The recipe index can be cached offline. Wiki Explorer is for detailed pages, enemies, quests, locations and everything else.</p></div>
  <div class="searchbox"><input id="wikiSearch" value="${esc(state.wikiQuery)}" placeholder="Potion, enemy, quest, item…"><button id="wikiGo">Search</button></div>
  <div class="wiki-categories">${wikiAreas.map(a=>`<button data-wiki-page="${esc(a[2])}"><b>${a[0]}</b><span>${esc(a[1])}</span></button>`).join('')}</div>
  <div class="notice"><strong>Online feature:</strong> detailed wiki search needs internet. Your synced recipe database and My Items continue to work offline.</div>
  <div id="wikiResults" class="cards">${recentWikiHTML()}</div>`;
}
function recentWikiHTML(){if(!state.recentWiki.length)return '<div class="empty">Search above, or choose a category to open the wiki.</div>';return `<div class="section-head" style="margin-top:2px"><div><h2>Recent lookups</h2><p>Stored only on this device</p></div></div>${state.recentWiki.map((q,i)=>`<article class="wiki-card" data-recent-wiki="${esc(q)}"><div class="wiki-index">${i+1}</div><a href="#"><h3>${esc(q)}</h3><p>Search the Outward Wiki again</p></a></article>`).join('')}`;}

function render(){
  const views={home,recipes,pantry,shopping,compare,wiki,guides,saved,settings};
  app.innerHTML=(views[state.route]||home)();app.setAttribute('aria-label',routeTitle(state.route));
  $$('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.route===state.route));renderDrawer();bindView();
}
function renderDrawer(){
  const nav=$('#drawerNav');
  nav.innerHTML=[['home','⌂','Home'],['recipes','⚗','Crafting & Recipes'],['pantry','🎒','My Items'],['shopping','🧾','Shopping List'],['compare','⚖','Compare'],['wiki','📖','Wiki Explorer'],['guides','✦','Field Guides'],['saved','♡','Saved'],['settings','⚙','Settings & Data']].map(([r,i,n])=>`<button data-drawer-route="${r}" class="${state.route===r?'active':''}">${i}&nbsp;&nbsp;${n}</button>`).join('');
  $$('[data-drawer-route]').forEach(b=>b.onclick=()=>setRoute(b.dataset.drawerRoute));
}
function setRoute(route,push=true){
  if(!allowedRoutes.has(route))route='home';state.route=route;closeDrawer();closeSheet();haptic();render();
  if(push&&location.protocol!=='file:'){const u=new URL(location.href);if(route==='home')u.searchParams.delete('route');else u.searchParams.set('route',route);history.pushState({route},'',u);}
  requestAnimationFrame(()=>window.scrollTo({top:0,behavior:'smooth'}));
}
function bindRecipeCards(root=document){
  root.querySelectorAll('[data-recipe]').forEach(el=>el.onclick=e=>{if(e.target.closest('[data-save]'))return;openRecipe(el.dataset.recipe);});
  root.querySelectorAll('[data-save]').forEach(el=>el.onclick=e=>{e.stopPropagation();toggleSave(el.dataset.save);});
}
function bindView(){
  $$('[data-go]').forEach(el=>el.onclick=()=>{if(el.dataset.filter){state.filter=el.dataset.filter;state.query='';state.purpose='All';}setRoute(el.dataset.go);});
  $$('.filter-row [data-filter]').forEach(el=>el.onclick=()=>{state.filter=el.dataset.filter;render();});
  $$('[data-purpose]').forEach(el=>el.onclick=()=>{state.purpose=el.dataset.purpose;render();});
  bindRecipeCards();

  const rs=$('#recipeSearch');if(rs){rs.oninput=e=>{state.query=e.target.value;const wrap=$('#recipeResults');if(wrap){wrap.innerHTML=recipeResultsHTML();bindRecipeCards(wrap);bindRecipeSearchExtras();}const c=$('#clearRecipeSearch');if(c)c.hidden=!state.query;};rs.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();rs.blur();}};}const crs=$('#clearRecipeSearch');if(crs)crs.onclick=()=>{state.query='';rs.value='';crs.hidden=true;const wrap=$('#recipeResults');wrap.innerHTML=recipeResultsHTML();bindRecipeCards(wrap);bindRecipeSearchExtras();};
  const hs=$('#homeSearch'),hg=$('#homeGo');if(hg)hg.onclick=()=>{state.query=hs.value;state.filter='All';state.purpose='All';hs.blur();setRoute('recipes');};if(hs)hs.onkeydown=e=>{if(e.key==='Enter')hg.click();};
  const sync=$('#syncRecipes');if(sync)sync.onclick=()=>syncRecipeDatabase();

  const pa=$('#pantryAdd'),pi=$('#pantryInput');if(pa)pa.onclick=()=>addPantry(pi.value);if(pi){pi.onkeydown=e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();pa.click();}};pi.oninput=e=>{state.ingredientQuery=e.target.value;const first=String(e.target.value).split(/[,;\n]/).pop();const box=$('#ingredientSuggestions');if(box)box.innerHTML=ingredientSuggestionHTML(first);bindIngredientSuggestions();};}
  bindIngredientSuggestions();
  $$('[data-quick-ingredient]').forEach(b=>b.onclick=()=>addPantry(b.dataset.quickIngredient));
  $$('[data-pantry-inc]').forEach(b=>b.onclick=()=>changePantry(decodeURIComponent(b.dataset.pantryInc),1));
  $$('[data-pantry-dec]').forEach(b=>b.onclick=()=>changePantry(decodeURIComponent(b.dataset.pantryDec),-1));
  $$('[data-ingredient-open]').forEach(b=>b.onclick=()=>openIngredient(b.dataset.ingredientOpen));
  const cp=$('#clearPantry');if(cp)cp.onclick=()=>{state.pantry=[];state.pantryQuery='';saveState();render();toast('Items cleared');};
  const prs=$('#pantryRecipeSearch');if(prs)prs.oninput=e=>{state.pantryQuery=e.target.value;render();requestAnimationFrame(()=>{const input=$('#pantryRecipeSearch');if(input){input.focus();input.setSelectionRange(input.value.length,input.value.length);}});};
  const si=$('#silverInput');if(si)si.onchange=e=>{state.silver=Math.max(0,Number(e.target.value)||0);saveState();render();};$$('[data-pantry-match]').forEach(b=>b.onclick=()=>{state.pantryMatch=b.dataset.pantryMatch;saveState();render();});
  const sl=$('#saveLoadout');if(sl)sl.onclick=saveLoadoutSheet;const ml=$('#manageLoadouts');if(ml)ml.onclick=openLoadoutsSheet;$$('[data-load-loadout]').forEach(b=>b.onclick=()=>loadLoadout(b.dataset.loadLoadout));

  const clearPlan=$('#clearPlan');if(clearPlan)clearPlan.onclick=()=>{state.plan.clear();saveState();render();toast('Shopping list cleared');};
  const copy=$('#copyShopping');if(copy)copy.onclick=copyShoppingList;

  $$('[data-compare-pick]').forEach(b=>b.onclick=()=>openRecipePicker(b.dataset.comparePick));const cc=$('#clearCompare');if(cc)cc.onclick=()=>{state.compareA='';state.compareB='';saveState();render();};

  const eb=$('#exportBackup');if(eb)eb.onclick=exportBackup;const cbk=$('#copyBackup');if(cbk)cbk.onclick=copyBackup;const pb=$('#pasteBackup');if(pb)pb.onclick=pasteBackupSheet;const ib=$('#importBackup');if(ib)ib.onchange=e=>importBackupFile(e.target.files?.[0]);const rd=$('#resetLocalData');if(rd)rd.onclick=resetDataSheet;
  bindRecipeSearchExtras();
  const wg=$('#wikiGo'),ws=$('#wikiSearch');if(wg)wg.onclick=()=>searchWiki(ws.value);if(ws)ws.onkeydown=e=>{if(e.key==='Enter')wg.click();};
  $$('[data-wiki-page]').forEach(b=>b.onclick=()=>openExternal(wikiURL(b.dataset.wikiPage)));$$('[data-recent-wiki]').forEach(c=>c.onclick=e=>{e.preventDefault();searchWiki(c.dataset.recentWiki);});
}
function bindRecipeSearchExtras(){
  $$('[data-wiki-search]').forEach(b=>b.onclick=()=>{const q=b.dataset.wikiSearch||state.query;state.wikiQuery=q;setRoute('wiki');requestAnimationFrame(()=>searchWiki(q));});
  const clear=$('#clearRecipeFilters');if(clear)clear.onclick=()=>{state.filter='All';state.purpose='All';state.query='';render();};
}
function bindIngredientSuggestions(){
  $$('[data-ingredient-suggestion]').forEach(b=>b.onclick=()=>{const input=$('#pantryInput');if(input)input.value=b.dataset.ingredientSuggestion;addPantry(b.dataset.ingredientSuggestion);});
}
function parsePantryInput(value){
  const chunks=String(value||'').split(/[\n,;]+/).map(x=>x.trim()).filter(Boolean);const out=[];
  for(const chunk of chunks){
    let name=chunk,count=1;let m=chunk.match(/^(\d+)\s*[x×]\s*(.+)$/i);
    if(m){count=Math.min(99,Math.max(1,Number(m[1])||1));name=m[2].trim();}
    else{m=chunk.match(/^(.+?)\s*[x×]\s*(\d+)$/i);if(m){name=m[1].trim();count=Math.min(99,Math.max(1,Number(m[2])||1));}}
    if(!name)continue;for(let i=0;i<count;i++)out.push(normalizeIngredient(name));
  }
  return out;
}
function addPantry(value){
  const items=parsePantryInput(value);if(!items.length)return toast('Enter an ingredient');
  state.pantry.push(...items);saveState();haptic();render();toast(items.length===1?`Added ${items[0]}`:`Added ${items.length} items`);
  requestAnimationFrame(()=>$('#pantryInput')?.focus());
}
function changePantry(key,delta){
  if(delta>0)state.pantry.push(ingredientByKey.get(key)||key);else{const idx=state.pantry.map(canon).lastIndexOf(key);if(idx>=0)state.pantry.splice(idx,1);}saveState();haptic();render();
}
function toggleSave(id){if(state.saved.has(id)){state.saved.delete(id);toast('Removed from saved');}else{state.saved.add(id);toast('Saved recipe');}saveState();haptic();render();}
function togglePlan(id){if(state.plan.has(id)){state.plan.delete(id);toast('Removed from shopping list');}else{state.plan.add(id);toast('Added to shopping list');}saveState();haptic();}

function saveLoadoutSheet(){
  if(!state.pantry.length)return toast('Add some items first');
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">My Items</div><h2>Save loadout</h2></div></div><p class="sheet-copy">Keep this ingredient setup so you can restore it later.</p><input class="sheet-input" id="loadoutName" placeholder="e.g. Cierzo supply run" maxlength="40"><button class="primary-btn full-btn" id="confirmLoadout">Save loadout</button>`);
  requestAnimationFrame(()=>$('#loadoutName')?.focus());$('#confirmLoadout').onclick=()=>{const name=$('#loadoutName').value.trim()||`Loadout ${state.loadouts.length+1}`;state.loadouts.unshift({id:`l-${Date.now().toString(36)}`,name,items:[...state.pantry],silver:Number(state.silver)||0,createdAt:Date.now()});state.loadouts=state.loadouts.slice(0,12);saveState();closeSheet();render();toast('Loadout saved');};
}
function openLoadoutsSheet(){
  const html=state.loadouts.length?state.loadouts.map(l=>`<div class="loadout-row"><button data-sheet-load="${esc(l.id)}"><strong>${esc(l.name)}</strong><small>${l.items.length} items${l.silver?` · ${l.silver} silver`:''}</small></button><button class="delete-mini" data-delete-loadout="${esc(l.id)}" aria-label="Delete ${esc(l.name)}">×</button></div>`).join(''):'<div class="empty">No saved loadouts yet.</div>';
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">My Items</div><h2>Saved loadouts</h2></div></div>${html}`);
  $$('[data-sheet-load]').forEach(b=>b.onclick=()=>{closeSheet();loadLoadout(b.dataset.sheetLoad);});$$('[data-delete-loadout]').forEach(b=>b.onclick=()=>{state.loadouts=state.loadouts.filter(l=>l.id!==b.dataset.deleteLoadout);saveState();closeSheet();openLoadoutsSheet();});
}
function loadLoadout(id){const l=state.loadouts.find(x=>x.id===id);if(!l)return;state.pantry=[...l.items];if(Number.isFinite(Number(l.silver)))state.silver=Math.max(0,Number(l.silver)||0);saveState();render();toast(`Loaded ${l.name}`);}
async function copyShoppingList(){
  const s=shoppingSummary();let text=s.missing.length?s.missing.map(([n,c])=>`${n} x${c}`).join('\n'):'No materials missing.';if(s.silverTotal)text+=`\nSilver needed: ${s.silverTotal}${s.silverShortfall?` (${s.silverShortfall} short)`:''}`;
  try{await navigator.clipboard.writeText(text);toast('Shopping list copied');}catch{if(navigator.share){try{await navigator.share({title:'Aurai Companion shopping list',text});}catch{}}else toast('Could not copy list');}
}

function showSheet(html){$('#infoSheetContent').innerHTML=html;$('#infoSheet').classList.add('open');$('#infoSheet').setAttribute('aria-hidden','false');$('#sheetBackdrop').classList.add('show');document.body.style.overflow='hidden';}
function closeSheet(){$('#infoSheet').classList.remove('open');$('#infoSheet').setAttribute('aria-hidden','true');$('#sheetBackdrop').classList.remove('show');document.body.style.overflow='';}
function openIngredient(name){
  const matches=catalogRecipes.filter(r=>(r.ingredients||[]).some(i=>canon(i)===canon(name))).slice(0,30);
  const current=state.pantry.filter(i=>canon(i)===canon(name)).length;
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">Ingredient</div><h2>${esc(name)}</h2><div class="meta"><span class="chip">${matches.length} recipe${matches.length===1?'':'s'}</span>${current?`<span class="chip green">In My Items ×${current}</span>`:''}</div></div></div>
    <div class="actions"><button class="primary-btn" id="ingredientAdd">+ Add to My Items</button><button class="secondary-btn" id="ingredientWiki">Open Wiki</button></div>
    <div class="detail-block"><h3>Recipes using it</h3><div class="ingredient-uses">${matches.length?matches.map(r=>`<button data-sheet-recipe="${esc(r.id)}"><span>${iconFor(r.type)} ${esc(r.name)}</span><small>${esc(r.station)}</small></button>`).join(''):'<div class="empty">No recipe in the current index uses this exact ingredient name.</div>'}</div></div>`);
  $('#ingredientAdd').onclick=()=>{state.pantry.push(normalizeIngredient(name));saveState();toast(`Added ${name}`);closeSheet();if(state.route==='pantry')render();};$('#ingredientWiki').onclick=()=>openExternal(wikiURL(name));
  $$('[data-sheet-recipe]').forEach(b=>b.onclick=()=>openRecipe(b.dataset.sheetRecipe));
}
function openRecipe(id){
  const r=getRecipe(id);if(!r)return;const status=state.pantry.length?pantryStatus(r):null;
  const pantryNote=status?status.craftable?`<div class="notice success-note"><strong>${r.type==='Blacksmith'?'Ready to commission':'Ready to make'}:</strong> your tracked requirements are covered.</div>`:status.materialsReady&&r.silverCost?`<div class="notice"><strong>Materials ready:</strong> you still need ${Math.max(0,status.silverNeeded-(Number(state.silver)||0))} silver.</div>`:status.haveUnits?`<div class="notice"><strong>From My Items:</strong> you have ${status.haveUnits}/${status.totalUnits}. Missing ${status.missing.map(([n,c])=>`${esc(n)}${c>1?` ×${c}`:''}`).join(', ')}.</div>`:'' :'';
  showSheet(`<div class="detail-head"><div><div class="hero-kicker">${esc(r.type)} · ${esc(r.station)}</div><h2>${esc(r.name)}</h2><div class="meta"><span class="chip gold">Makes ${esc(r.yield)}</span>${(r.tags||[]).slice(0,4).map(t=>`<span class="chip">${esc(t)}</span>`).join('')}${r.source==='wiki-index'?'<span class="chip blue">Offline index</span>':''}</div></div></div>
    <div class="detail-block"><h3>${r.type==='Blacksmith'?'Materials':'Ingredients'}</h3><div class="ingredient-list">${countIngredients(r.ingredients).map(([name,count])=>`<button class="ingredient-row ingredient-link" data-ingredient-open="${esc(name)}"><span>${esc(name)}</span><strong>×${count} ›</strong></button>`).join('')}${r.silverCost?`<div class="ingredient-row"><span>Silver</span><strong>×${esc(r.silverCost)}</strong></div>`:''}</div></div>${pantryNote}
    ${r.note?`<div class="detail-block"><h3>Quick note</h3><div class="notice">${esc(r.note)}</div></div>`:''}
    <div class="actions"><button class="secondary-btn" id="sheetSave">${state.saved.has(r.id)?'♥ Saved':'♡ Save'}</button><button class="primary-btn" id="sheetWiki">Open Wiki</button></div>
    <div class="actions"><button class="secondary-btn" id="sheetPlan">${state.plan.has(r.id)?'✓ In shopping list':'＋ Shopping list'}</button><button class="secondary-btn" id="sheetCompare">⚖ Compare</button></div>
    ${navigator.share?'<div class="actions"><button class="secondary-btn" id="sheetShare">Share recipe</button></div>':''}`);
  $('#sheetSave').onclick=()=>{toggleSave(r.id);closeSheet();};$('#sheetWiki').onclick=()=>openExternal(wikiURL(r.wiki||r.name));$('#sheetPlan').onclick=()=>{togglePlan(r.id);closeSheet();render();};
  $('#sheetCompare').onclick=()=>{if(!state.compareA||state.compareA===r.id)state.compareA=r.id;else state.compareB=r.id;saveState();closeSheet();setRoute('compare');};
  $$('[data-ingredient-open]').forEach(b=>b.onclick=()=>openIngredient(b.dataset.ingredientOpen));
  const share=$('#sheetShare');if(share)share.onclick=async()=>{try{await navigator.share({title:`${r.name} — Aurai Companion`,text:`${r.name}: ${r.ingredients.join(', ')}`,url:wikiURL(r.wiki||r.name)});}catch{}};
}

async function searchWiki(raw){
  const q=String(raw||'').trim();if(!q)return toast('Enter something to search');state.wikiQuery=q;state.recentWiki=[q,...state.recentWiki.filter(x=>x.toLowerCase()!==q.toLowerCase())].slice(0,6);saveState();
  const target=$('#wikiResults');if(!target)return;target.innerHTML='<div class="wiki-status"><div class="spinner"></div>Searching Outward Wiki…</div>';wikiAbort?.abort();wikiAbort=new AbortController();
  try{const url=`${WIKI_API}?action=query&format=json&origin=*&list=search&srlimit=12&srnamespace=0&srsearch=${encodeURIComponent(q)}`;const res=await fetch(url,{signal:wikiAbort.signal,headers:{Accept:'application/json'}});if(!res.ok)throw new Error(`HTTP ${res.status}`);const data=await res.json();const results=data?.query?.search||[];
    if(!results.length){target.innerHTML=`<div class="empty">No live results for “${esc(q)}”. <button class="link-btn" id="wikiFallback">Open wiki search</button></div>`;$('#wikiFallback').onclick=()=>openExternal(`${WIKI}/index.php?search=${encodeURIComponent(q)}`);return;}
    target.innerHTML=results.map((r,i)=>`<article class="wiki-card" data-wiki-url="${esc(wikiURL(r.title))}"><div class="wiki-index">${i+1}</div><a href="#"><h3>${esc(r.title)}</h3><p>${esc(stripHTML(r.snippet)||'Open this article on the Outward Wiki.')}</p></a></article>`).join('');$$('[data-wiki-url]').forEach(c=>c.onclick=e=>{e.preventDefault();openExternal(c.dataset.wikiUrl);});
  }catch(err){if(err.name==='AbortError')return;target.innerHTML=`<div class="empty">Live lookup could not connect. <button class="link-btn" id="wikiFallback">Search outward.wiki.gg directly</button></div>`;$('#wikiFallback').onclick=()=>openExternal(`${WIKI}/index.php?search=${encodeURIComponent(q)}`);}
}

function openDrawer(){$('#drawer').classList.add('open');$('#drawer').setAttribute('aria-hidden','false');$('#backdrop').classList.add('show');}
function closeDrawer(){$('#drawer').classList.remove('open');$('#drawer').setAttribute('aria-hidden','true');$('#backdrop').classList.remove('show');}
function installSheetHTML(){
  if(IS_NATIVE)return `<div class="install-card"><img src="icon.svg" alt=""><h2>Aurai Companion</h2><p>The Android app is installed and ready to use.</p><div class="install-steps"><div><span class="step-num">✓</span><span>Recipes, My Items, saved recipes, loadouts and shopping lists stay on this phone.</span></div><div><span class="step-num">✓</span><span>Sync the recipe database while online, then use it offline.</span></div></div><small>Version ${APP_VERSION}</small></div>`;
  if(IS_STANDALONE)return `<div class="install-card"><img src="icon.svg" alt=""><h2>Already installed</h2><p>Aurai Companion is running in standalone app mode.</p><div class="install-steps"><div><span class="step-num">✓</span><span>Launch it from your home screen or app drawer.</span></div><div><span class="step-num">✓</span><span>Hosted web updates are checked automatically.</span></div></div><small>Version ${APP_VERSION}</small></div>`;
  if(deferredInstallPrompt)return `<div class="install-card"><img src="icon.svg" alt=""><h2>Install Aurai Companion</h2><p>Add it to this phone so it opens like a normal app.</p><div class="install-steps"><div><span class="step-num">1</span><span>Tap <strong>Install now</strong>.</span></div><div><span class="step-num">2</span><span>Confirm the browser install prompt.</span></div></div><button class="primary-btn" id="installNow" style="width:100%">Install now</button></div>`;
  const isiOS=/iphone|ipad|ipod/i.test(navigator.userAgent);return `<div class="install-card"><img src="icon.svg" alt=""><h2>Install on this phone</h2><p>${isiOS?'Safari installs web apps from the Share menu.':'Open the browser menu and choose Install app or Add to Home screen.'}</p><small>Version ${APP_VERSION}</small></div>`;
}
function showInstallSheet(){showSheet(installSheetHTML());const btn=$('#installNow');if(btn)btn.onclick=async()=>{try{await deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;closeSheet();}catch{toast('Install prompt unavailable');}};}
function updateNetworkLabel(){const l=$('#networkLabel');if(!l)return;if(navigator.onLine){l.textContent=state.dbSource==='wiki-cache'?`Online · ${catalogRecipes.length} recipes cached`:'Online · recipe sync available';l.className='online';}else{l.textContent=state.dbSource==='wiki-cache'?`Offline · ${catalogRecipes.length} recipes cached`:'Offline · starter recipes';l.className='offline';}}
function showUpdate(){if(IS_NATIVE)return;const bar=$('#updateBar');if(bar)bar.hidden=false;}
function hideUpdate(){const bar=$('#updateBar');if(bar)bar.hidden=true;}
async function checkForUpdate(){if(IS_NATIVE)return toast('APK updates come from your GitHub build');if(!swRegistration)return toast('Update checks need the hosted web version');try{await swRegistration.update();toast(swRegistration.waiting?'Update ready':'You’re up to date');if(swRegistration.waiting)showUpdate();}catch{toast('Could not check for updates');}}
function registerServiceWorker(){if(IS_NATIVE||!('serviceWorker' in navigator)||!/^https?:$/.test(location.protocol))return;navigator.serviceWorker.register('./sw.js').then(reg=>{swRegistration=reg;if(reg.waiting)showUpdate();reg.addEventListener('updatefound',()=>{const worker=reg.installing;if(!worker)return;worker.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller)showUpdate();});});}).catch(()=>{});navigator.serviceWorker.addEventListener('controllerchange',()=>{if(reloadingForUpdate)return;reloadingForUpdate=true;location.reload();});}

$('#menuBtn').onclick=openDrawer;$('#backdrop').onclick=closeDrawer;$('#brandHome').onclick=()=>setRoute('home');$('#installBtn').onclick=showInstallSheet;$('#drawerInstall').onclick=()=>{closeDrawer();showInstallSheet();};$('#drawerUpdate').onclick=()=>{closeDrawer();checkForUpdate();};$('#sheetBackdrop').onclick=closeSheet;$$('[data-close-sheet]').forEach(b=>b.onclick=closeSheet);$('#dismissUpdate').onclick=hideUpdate;$('#applyUpdate').onclick=()=>{if(swRegistration?.waiting){hideUpdate();swRegistration.waiting.postMessage({type:'SKIP_WAITING'});toast('Updating…');}else{hideUpdate();toast('No web update is waiting');}};
$$('.bottom-nav button').forEach(b=>b.onclick=()=>setRoute(b.dataset.route));window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;$('#installBtn').hidden=false;});window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;toast('Aurai Companion installed');});window.addEventListener('online',()=>{updateNetworkLabel();if(state.dbSource!=='wiki-cache')syncRecipeDatabase({silent:true});});window.addEventListener('offline',updateNetworkLabel);window.addEventListener('popstate',e=>{const u=new URL(location.href);const r=e.state?.route||u.searchParams.get('route')||'home';state.route=allowedRoutes.has(r)?r:'home';render();});window.addEventListener('keydown',e=>{if(e.key==='Escape'){closeDrawer();closeSheet();}});

if(IS_NATIVE){hideUpdate();const updateButton=$('#drawerUpdate');if(updateButton)updateButton.hidden=true;const installButton=$('#installBtn');if(installButton)installButton.setAttribute('aria-label','App info');const drawerInstall=$('#drawerInstall');if(drawerInstall)drawerInstall.textContent='App info';}
updateNetworkLabel();render();registerServiceWorker();initRecipeDatabase().finally(updateNetworkLabel);setTimeout(()=>$('#splash')?.classList.add('hide'),520);
